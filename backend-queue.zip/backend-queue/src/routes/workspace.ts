import { Router, Request, Response, NextFunction } from 'express';
import pool, { withTransaction } from '../db/pool';
import { authenticate } from '../middleware/auth';
import { AppError } from '../middleware/errorHandler';

const router = Router();
router.use(authenticate);

const REJECTION_CODES = [
  'NOT_READY',
  'NEED_BREAK',
  'SKILL_MISMATCH',
  'TECHNICAL_ISSUE',
  'SUPERVISOR_HOLD',
];

// Minimum minutes that must elapse since the last non-pending attempt on a
// contact before the dispatcher will hand it out again. Defaults to 240 (the
// historical 4-hour rule). Set DIALER_MIN_REDIAL_MINUTES=0 to disable the
// floor entirely and let the per-disposition next_attempt_at be the only
// re-dial cool-off.
const MIN_REDIAL_MINUTES = (() => {
  const raw = process.env.DIALER_MIN_REDIAL_MINUTES;
  if (raw === undefined || raw === '') return 240;
  const n = Number.parseInt(raw, 10);
  return Number.isFinite(n) && n >= 0 ? n : 240;
})();

// PATCH /sessions/ready
router.patch(
  '/sessions/ready',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { selected_job_ids } = req.body;
      if (!Array.isArray(selected_job_ids) || !selected_job_ids.length)
        throw new AppError(400, 'selected_job_ids array required');

      // Verify all jobs are active
      const { rows: jobCheck } = await pool.query(
        `SELECT id FROM campaign_jobs WHERE id = ANY($1) AND status = 'active'`,
        [selected_job_ids],
      );
      if (jobCheck.length !== selected_job_ids.length)
        throw new AppError(400, 'One or more job IDs are not active');

      // Upsert agent session
      const { rows } = await pool.query(
        `INSERT INTO agent_sessions (agent_id, selected_job_ids, status, last_heartbeat_at)
       VALUES ($1, $2, 'available', NOW())
       ON CONFLICT (agent_id) DO UPDATE
         SET selected_job_ids = $2,
             status = 'available',
             last_heartbeat_at = NOW(),
             logout_at = NULL
       RETURNING *`,
        [req.user!.userId, selected_job_ids],
      );
      res.json({
        session_id: rows[0].id,
        status: 'available',
        selected_job_ids,
      });
    } catch (err) {
      next(err);
    }
  },
);

// GET /workspace/next-contact — the core atomic fetch
router.get(
  '/workspace/next-contact',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const agentId = req.user!.userId;

      // Get active session
      const { rows: sessRows } = await pool.query(
        `SELECT * FROM agent_sessions WHERE agent_id=$1 AND status='available'`,
        [agentId],
      );
      if (!sessRows[0])
        throw new AppError(400, 'Session not in available status');
      const session = sessRows[0];

      if (!session.selected_job_ids?.length)
        throw new AppError(400, 'No jobs selected for this session');

      // Get campaign config for agent priority check
      const { rows: jobCamps } = await pool.query(
        `SELECT cj.id as job_id, c.agent_priority_enabled, c.auto_dial_delay_sec, c.name as campaign_name
       FROM campaign_jobs cj
       JOIN campaigns c ON c.id = cj.campaign_id
       WHERE cj.id = ANY($1) AND cj.status = 'active'`,
        [session.selected_job_ids],
      );
      const agentPriorityEnabled = jobCamps.some(
        (j) => j.agent_priority_enabled,
      );
      const autoDialDelay = jobCamps[0]?.auto_dial_delay_sec || 8;

      // Build the fetch query dynamically based on agent priority
      const assignmentFilter = agentPriorityEnabled
        ? `AND (ccs.assigned_agent_id = $2 OR ccs.assigned_agent_id IS NULL)`
        : '';
      const orderBy = agentPriorityEnabled
        ? `CASE WHEN ccs.assigned_agent_id = $2 THEN 0 ELSE 1 END ASC, ccs.priority ASC, ccs.next_attempt_at ASC`
        : `ccs.priority ASC, ccs.next_attempt_at ASC`;

      const fetchParams: any[] = [session.selected_job_ids];
      if (agentPriorityEnabled) fetchParams.push(agentId);

      const result = await withTransaction(async (client) => {
        // Atomic: find + lock CCS row.
        //
        // Eligibility rules, evaluated together so a contact is only handed
        // to an agent when ALL of these are true:
        //   1. CCS row is queued, due, unlocked, not already with an agent.
        //   2. Campaign is within its start_date / end_date window
        //      (NULL on either side means "unbounded that direction").
        //   3. If the campaign has a schedule_template_id, today's day-of-week
        //      and the current local time (in the TEMPLATE's timezone) must
        //      fall inside one of that template's schedule_windows. Campaigns
        //      without a template dial 24/7.
        //   4. If the campaign has a holiday_calendar_id, today (in the
        //      template's timezone, falling back to UTC) must NOT be a
        //      full-day holiday block AND the current local time must NOT
        //      fall inside a partial block_start..block_end slot.
        //   5. Phone number is not on a DNC group attached to the campaign.
        //   6. No non-pending attempt happened in the last 4 hours
        //      (per-contact cool-off).
        //   7. Agent-priority assignment filter (when the campaign opts in).
        const { rows: ccsRows } = await client.query(
          `SELECT ccs.*, c.phone_number, c.first_name, c.last_name, c.custom_fields,
                c.priority as contact_priority, cj.campaign_id,
                camp.name as campaign_name, camp.auto_dial_delay_sec
         FROM campaign_contact_status ccs
         JOIN contacts c ON c.id = ccs.contact_id
         JOIN campaign_jobs cj ON cj.id = ccs.job_id
         JOIN campaigns camp ON camp.id = cj.campaign_id
         LEFT JOIN schedule_templates st ON st.id = camp.schedule_template_id
         WHERE ccs.job_id = ANY($1)
           AND ccs.status = 'queued'
           AND ccs.next_attempt_at <= NOW()
           AND ccs.locked_by_session IS NULL
           -- (2) Campaign date-range gate.
           AND (camp.start_date IS NULL OR camp.start_date <= CURRENT_DATE)
           AND (camp.end_date   IS NULL OR camp.end_date   >= CURRENT_DATE)
           -- (3) Schedule template window gate. EXTRACT(DOW) returns
           --     0=Sunday..6=Saturday which matches schedule_windows.day_of_week.
           --     "(NOW() AT TIME ZONE st.timezone)" returns the wall-clock
           --     timestamp in that zone; we cast to date for DOW and to time
           --     for the start/end comparison.
           AND (
             camp.schedule_template_id IS NULL
             OR EXISTS (
               SELECT 1 FROM schedule_windows sw
                WHERE sw.schedule_template_id = camp.schedule_template_id
                  AND sw.day_of_week =
                    EXTRACT(DOW FROM (NOW() AT TIME ZONE st.timezone))::int
                  AND (NOW() AT TIME ZONE st.timezone)::time
                      BETWEEN sw.start_time AND sw.end_time
             )
           )
           -- (4) Holiday calendar gate. Falls back to UTC when no template
           --     timezone is configured so the check is still timezone-aware
           --     for the partial-block case.
           AND NOT EXISTS (
             SELECT 1 FROM holiday_dates hd
              WHERE hd.calendar_id = camp.holiday_calendar_id
                AND hd.holiday_date =
                  (NOW() AT TIME ZONE COALESCE(st.timezone, 'UTC'))::date
                AND (
                  hd.is_full_day_block = TRUE
                  OR (NOW() AT TIME ZONE COALESCE(st.timezone, 'UTC'))::time
                       BETWEEN hd.block_start AND hd.block_end
                )
           )
           -- (5) DNC suppression at the campaign level.
           AND c.phone_number NOT IN (
             SELECT dn.phone_number FROM dnc_numbers dn
             JOIN campaign_dnc_groups cdg ON cdg.dnc_group_id = dn.dnc_group_id
             WHERE cdg.campaign_id = cj.campaign_id
           )
           -- (6) Per-contact recent-attempt cool-off. Configurable via
           --     DIALER_MIN_REDIAL_MINUTES (default 240). When set to 0
           --     the clause is omitted so only next_attempt_at governs.
           ${MIN_REDIAL_MINUTES > 0
            ? `AND NOT EXISTS (
             SELECT 1 FROM contact_interactions ci
             WHERE ci.contact_id = ccs.contact_id
               AND ci.dialed_at >= NOW() - INTERVAL '${MIN_REDIAL_MINUTES} minutes'
               AND ci.call_status != 'pending'
           )`
            : ''
          }
           ${assignmentFilter}
         ORDER BY ${orderBy}
         LIMIT 1
         FOR UPDATE OF ccs SKIP LOCKED`,
          fetchParams,
        );

        if (!ccsRows[0]) return null; // No contact available

        const ccs = ccsRows[0];

        // Lock the CCS row + set status=with_agent
        await client.query(
          `UPDATE campaign_contact_status
         SET locked_by_session=$1, locked_at=NOW(), status='with_agent', updated_at=NOW()
         WHERE id=$2`,
          [session.id, ccs.id],
        );

        // Insert contact_interactions row (given_at only)
        const givenAt = new Date();
        const autoDialFiresAt = new Date(
          givenAt.getTime() + autoDialDelay * 1000,
        );

        const { rows: interRows } = await client.query(
          `INSERT INTO contact_interactions
           (contact_id, job_id, agent_id, agent_session_id,
            attempt_number, dial_mode, given_at, auto_dial_fires_at, preview_action)
         VALUES ($1,$2,$3,$4,$5,'auto',$6,$7,'pending')
         RETURNING id`,
          [
            ccs.contact_id,
            ccs.job_id,
            agentId,
            session.id,
            ccs.attempts_made + 1,
            givenAt,
            autoDialFiresAt,
          ],
        );

        // Update agent session
        await client.query(
          `UPDATE agent_sessions
         SET status='with_agent', current_contact_id=$1, current_job_id=$2,
             last_heartbeat_at=NOW()
         WHERE id=$3`,
          [ccs.contact_id, ccs.job_id, session.id],
        );

        // Get field definitions for preview card
        const { rows: fieldDefs } = await client.query(
          `SELECT field_key, field_label, data_type, field_type, display_order, is_visible_to_agent
         FROM contact_list_field_definitions
         WHERE contact_list_id = (
           SELECT contact_list_id FROM contacts WHERE id=$1
         ) AND is_visible_to_agent = true
         ORDER BY display_order`,
          [ccs.contact_id],
        );

        return {
          interaction_id: interRows[0].id,
          ccs_id: ccs.id,
          contact_id: ccs.contact_id,
          job_id: ccs.job_id,
          campaign_name: ccs.campaign_name,
          phone_number: ccs.phone_number,
          first_name: ccs.first_name,
          last_name: ccs.last_name,
          attempt_number: ccs.attempts_made + 1,
          priority: ccs.contact_priority,
          assigned_agent_id: ccs.assigned_agent_id,
          custom_fields: ccs.custom_fields,
          field_definitions: fieldDefs,
          auto_dial_in_sec: autoDialDelay,
          given_at: givenAt.toISOString(),
        };
      });

      if (!result) {
        // Distinguish "nothing right now" (cool-off, locked, recent-attempt
        // skip) from "nothing ever" (every CCS row terminal). The frontend
        // uses this to switch from a polling spinner to a final "completed"
        // screen. Contacts sitting in a future next_attempt_at cool-off
        // are NOT treated as terminal — the agent stays on the spinner
        // and the next poll picks them up automatically once their
        // cool-off elapses.
        const { rows: aggRows } = await pool.query(
          `SELECT
             COUNT(*)::int AS total,
             COUNT(*) FILTER (
               WHERE status IN ('completed','exhausted','dnc')
             )::int AS terminal,
             COUNT(*) FILTER (WHERE status = 'with_agent')::int AS with_agent,
             COUNT(*) FILTER (
               WHERE status = 'queued' AND next_attempt_at > NOW()
             )::int AS waiting
           FROM campaign_contact_status
           WHERE job_id = ANY($1)`,
          [session.selected_job_ids],
        );
        const agg = aggRows[0] || {
          total: 0,
          terminal: 0,
          with_agent: 0,
          waiting: 0,
        };
        const exhausted = agg.total === 0 || agg.terminal === agg.total;
        if (exhausted) {
          res.json({
            exhausted: true,
            breakdown: {
              total: agg.total,
              completed: agg.terminal,
              with_agent: agg.with_agent,
              waiting: agg.waiting,
            },
          });
          return;
        }
        res.status(204).set('Retry-After-Ms', '5000').send();
        return;
      }
      res.json(result);
    } catch (err) {
      next(err);
    }
  },
);

// POST /workspace/reject
router.post(
  '/workspace/reject',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { interaction_id, rejection_reason } = req.body;
      if (!interaction_id) throw new AppError(400, 'interaction_id required');
      if (!REJECTION_CODES.includes(rejection_reason))
        throw new AppError(
          400,
          `rejection_reason must be one of: ${REJECTION_CODES.join(', ')}`,
        );

      await withTransaction(async (client) => {
        const { rows: intRows } = await client.query(
          `SELECT * FROM contact_interactions WHERE id=$1 AND agent_id=$2 AND preview_action='pending'`,
          [interaction_id, req.user!.userId],
        );
        if (!intRows[0])
          throw new AppError(404, 'Interaction not found or already closed');
        const interaction = intRows[0];

        // Update contact_interactions
        await client.query(
          `UPDATE contact_interactions
         SET preview_action='rejected', rejected_at=NOW(),
             rejection_reason=$1, agent_session_id=NULL
         WHERE id=$2`,
          [rejection_reason, interaction_id],
        );

        // Release CCS — no cooldown on reject (contact wasn't called)
        await client.query(
          `UPDATE campaign_contact_status
         SET status='queued', locked_by_session=NULL, locked_at=NULL,
             next_attempt_at=NOW(), updated_at=NOW()
         WHERE contact_id=$1 AND job_id=$2`,
          [interaction.contact_id, interaction.job_id],
        );

        // Reset agent session
        await client.query(
          `UPDATE agent_sessions
         SET status='available', current_contact_id=NULL, current_job_id=NULL
         WHERE agent_id=$1`,
          [req.user!.userId],
        );
      });

      res.json({ interaction_id, status: 'rejected', re_queued: true });
    } catch (err) {
      next(err);
    }
  },
);

// POST /workspace/disposition — the single final UPDATE on contact_interactions
router.post(
  '/workspace/disposition',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const {
        interaction_id,
        disposition_code_id,
        accepted_at,
        dialed_at,
        answered_at,
        disconnected_at,
        call_status,
        telephony_call_sid,
        recording_url,
        reschedule_at,
        notes,
      } = req.body;

      if (!interaction_id) throw new AppError(400, 'interaction_id required');
      if (!disposition_code_id)
        throw new AppError(400, 'disposition_code_id required');
      if (!accepted_at) throw new AppError(400, 'accepted_at required');
      if (!dialed_at) throw new AppError(400, 'dialed_at required');
      if (!disconnected_at) throw new AppError(400, 'disconnected_at required');
      if (!call_status) throw new AppError(400, 'call_status required');

      const result = await withTransaction(async (client) => {
        // Validate interaction
        const { rows: intRows } = await client.query(
          `SELECT * FROM contact_interactions WHERE id=$1 AND agent_id=$2 AND wrapup_at IS NULL`,
          [interaction_id, req.user!.userId],
        );
        if (!intRows[0])
          throw new AppError(404, 'Interaction not found or already disposed');
        const interaction = intRows[0];

        // Get disposition code
        const { rows: codeRows } = await client.query(
          'SELECT * FROM disposition_codes WHERE id=$1',
          [disposition_code_id],
        );
        if (!codeRows[0])
          throw new AppError(400, 'Invalid disposition_code_id');
        const code = codeRows[0];
        if (code.notes_required && !notes)
          throw new AppError(400, `Notes required for ${code.code}`);
        if (
          code.capability === 'RESCHEDULE' &&
          !reschedule_at &&
          !code.retry_delay_min
        )
          throw new AppError(
            400,
            'reschedule_at required for RESCHEDULE disposition',
          );

        const wrapupAt = new Date();

        // Compute durations
        const givenAt = new Date(interaction.given_at);
        const acceptedDate = new Date(accepted_at);
        const disconnDate = new Date(disconnected_at);
        const answeredDate = answered_at ? new Date(answered_at) : null;

        const previewDurationSec = Math.round(
          (acceptedDate.getTime() - givenAt.getTime()) / 1000,
        );
        const talkTimeSec = answeredDate
          ? Math.round((disconnDate.getTime() - answeredDate.getTime()) / 1000)
          : null;
        const wrapupDurationSec = Math.round(
          (wrapupAt.getTime() - disconnDate.getTime()) / 1000,
        );
        const totalHandlingSec = Math.round(
          (wrapupAt.getTime() - givenAt.getTime()) / 1000,
        );

        // Single final UPDATE on contact_interactions
        await client.query(
          `UPDATE contact_interactions SET
           preview_action = 'accepted',
           accepted_at = $1, dialed_at = $2, answered_at = $3,
           disconnected_at = $4, wrapup_at = $5,
           preview_duration_sec = $6, talk_time_sec = $7,
           wrapup_duration_sec = $8, total_handling_sec = $9,
           call_status = $10, telephony_call_sid = $11, recording_url = $12,
           disposition_code_id = $13, disposition_capability = $14,
           reschedule_at = $15, disposition_notes = $16,
           agent_session_id = NULL
         WHERE id = $17`,
          [
            accepted_at,
            dialed_at,
            answered_at || null,
            disconnected_at,
            wrapupAt,
            previewDurationSec,
            talkTimeSec,
            wrapupDurationSec,
            totalHandlingSec,
            call_status,
            telephony_call_sid || null,
            recording_url || null,
            disposition_code_id,
            code.capability,
            reschedule_at || null,
            notes || null,
            interaction_id,
          ],
        );

        // Get campaign config for max_attempts. Re-dial timing now comes
        // from the disposition's retry_delay_min (the campaign's old
        // attempt_interval_min has been repurposed as wrapup_time_sec — a
        // post-call wrap-up window for the agent, not a redial cool-off).
        const { rows: campRows } = await client.query(
          `SELECT c.max_attempts FROM campaigns c
         JOIN campaign_jobs cj ON cj.campaign_id = c.id
         WHERE cj.id = $1`,
          [interaction.job_id],
        );
        const maxAttempts = campRows[0]?.max_attempts;
        const retryMinutes = code.retry_delay_min ?? 90;

        // Get current attempts_made
        const { rows: ccsRows } = await client.query(
          `SELECT attempts_made FROM campaign_contact_status
         WHERE contact_id=$1 AND job_id=$2`,
          [interaction.contact_id, interaction.job_id],
        );
        const newAttemptsMade = (ccsRows[0]?.attempts_made || 0) + 1;
        const isExhausted = maxAttempts && newAttemptsMade >= maxAttempts;

        // Determine new CCS status from capability
        let ccsStatus: string;
        let nextAttemptAt: string | null = null;

        if (code.capability === 'CLOSED' || code.code === 'DNC') {
          ccsStatus = code.code === 'DNC' ? 'dnc' : 'completed';
        } else if (isExhausted) {
          ccsStatus = 'exhausted';
        } else if (code.capability === 'RESCHEDULE') {
          ccsStatus = 'queued';
          nextAttemptAt =
            reschedule_at ||
            new Date(Date.now() + retryMinutes * 60000).toISOString();
        } else {
          // NEXT_ATTEMPT
          ccsStatus = 'queued';
          nextAttemptAt = new Date(
            Date.now() + retryMinutes * 60000,
          ).toISOString();
        }

        // Update CCS
        await client.query(
          `UPDATE campaign_contact_status SET
           status = $1,
           locked_by_session = NULL,
           locked_at = NULL,
           next_attempt_at = COALESCE($2::timestamptz, next_attempt_at),
           attempts_made = $3,
           last_attempted_at = NOW(),
           updated_at = NOW()
         WHERE contact_id=$4 AND job_id=$5`,
          [
            ccsStatus,
            nextAttemptAt,
            newAttemptsMade,
            interaction.contact_id,
            interaction.job_id,
          ],
        );

        // DNC: add to dnc_numbers. Numbers live under a list, so we first
        // resolve (or auto-create) an 'Agent Disposition' list inside the
        // campaign's linked group and target that list.
        if (code.code === 'DNC') {
          const { rows: dncGroupRows } = await client.query(
            `SELECT dg.id FROM dnc_groups dg
           JOIN campaign_dnc_groups cdg ON cdg.dnc_group_id = dg.id
           JOIN campaign_jobs cj ON cj.campaign_id = cdg.campaign_id
           WHERE cj.id = $1 LIMIT 1`,
            [interaction.job_id],
          );
          if (dncGroupRows[0]) {
            const groupId = dncGroupRows[0].id;
            const { rows: listRows } = await client.query(
              `INSERT INTO dnc_lists (dnc_group_id, name, source, created_by)
               VALUES ($1, 'Agent Disposition', 'agent_disposition', $2)
               ON CONFLICT (dnc_group_id, name) DO UPDATE SET updated_at = NOW()
               RETURNING id`,
              [groupId, req.user!.userId],
            );
            const listId = listRows[0].id;
            await client.query(
              `INSERT INTO dnc_numbers (dnc_list_id, dnc_group_id, phone_number, added_reason, added_by)
             SELECT $1, $2, c.phone_number, 'agent_marked', $3
             FROM contacts c WHERE c.id = $4
             ON CONFLICT DO NOTHING`,
              [listId, groupId, req.user!.userId, interaction.contact_id],
            );
          }
        }

        // Status history
        await client.query(
          `INSERT INTO contact_status_history
           (contact_id, job_id, from_status, to_status, trigger_type, triggered_by)
         VALUES ($1,$2,'with_agent',$3,'disposition',$4)`,
          [
            interaction.contact_id,
            interaction.job_id,
            ccsStatus,
            req.user!.userId,
          ],
        );

        // Agent session back to available
        await client.query(
          `UPDATE agent_sessions SET
           status='available', current_contact_id=NULL, current_job_id=NULL
         WHERE agent_id=$1`,
          [req.user!.userId],
        );

        // Check finite campaign auto-close
        const { rows: pendingRows } = await client.query(
          `SELECT COUNT(*)::int AS cnt FROM campaign_contact_status
         WHERE job_id=$1 AND status NOT IN ('completed','exhausted','dnc')`,
          [interaction.job_id],
        );
        if (pendingRows[0].cnt === 0) {
          const { rows: jobRows } = await client.query(
            `SELECT cj.id, c.schedule_type FROM campaign_jobs cj
           JOIN campaigns c ON c.id = cj.campaign_id
           WHERE cj.id=$1`,
            [interaction.job_id],
          );
          if (jobRows[0]?.schedule_type === 'finite') {
            await client.query(
              `UPDATE campaign_jobs SET status='completed', end_time=NOW() WHERE id=$1`,
              [interaction.job_id],
            );
            await client.query(
              `UPDATE campaigns SET status='completed', updated_at=NOW()
             WHERE id=(SELECT campaign_id FROM campaign_jobs WHERE id=$1)`,
              [interaction.job_id],
            );
          }
        }

        return {
          interaction_id,
          contact_id: interaction.contact_id,
          disposition_code: code.code,
          capability: code.capability,
          ccs_status: ccsStatus,
          next_attempt_at: nextAttemptAt,
          preview_duration_sec: previewDurationSec,
          talk_time_sec: talkTimeSec,
          wrapup_duration_sec: wrapupDurationSec,
          total_handling_sec: totalHandlingSec,
        };
      });

      res.json(result);
    } catch (err) {
      next(err);
    }
  },
);

// POST /sessions/heartbeat
router.post(
  '/sessions/heartbeat',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { rows } = await pool.query(
        `UPDATE agent_sessions SET last_heartbeat_at=NOW()
       WHERE agent_id=$1 AND status != 'offline' RETURNING *`,
        [req.user!.userId],
      );
      if (!rows[0])
        throw new AppError(404, 'Session not found or already offline');
      res.json({
        session_id: rows[0].id,
        last_heartbeat_at: rows[0].last_heartbeat_at,
        status: rows[0].status,
      });
    } catch (err) {
      next(err);
    }
  },
);

// PATCH /sessions/offline
router.patch(
  '/sessions/offline',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { rows: active } = await pool.query(
        `SELECT 1 FROM agent_sessions WHERE agent_id=$1 AND status='with_agent'`,
        [req.user!.userId],
      );
      if (active.length)
        throw new AppError(409, 'Active contact in progress — dispose first');

      const { rows } = await pool.query(
        `UPDATE agent_sessions SET status='offline', logout_at=NOW()
       WHERE agent_id=$1 RETURNING *`,
        [req.user!.userId],
      );
      res.json({
        session_id: rows[0]?.id,
        status: 'offline',
        logout_at: rows[0]?.logout_at,
      });
    } catch (err) {
      next(err);
    }
  },
);

export default router;
