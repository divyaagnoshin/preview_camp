import React, { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getCampaigns, getCampaignReport, getInteractions } from '../api/client';
import { StatusBadge, PageLoader, Badge } from '../components/ui';
import {
  BarChart2, ChevronDown, ChevronUp, Calendar, Filter,
} from 'lucide-react';

/* ─── helpers ──────────────────────────────────────────────────── */
const STATUS_STYLES: Record<string, { bg: string; text: string; dot: string }> = {
  active:    { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  paused:    { bg: 'bg-amber-50',   text: 'text-amber-700',   dot: 'bg-amber-400'   },
  draft:     { bg: 'bg-gray-100',   text: 'text-gray-500',    dot: 'bg-gray-400'    },
  completed: { bg: 'bg-blue-50',    text: 'text-blue-700',    dot: 'bg-blue-500'    },
};

function StatusPill({ status }: { status: string }) {
  const s = STATUS_STYLES[status] || STATUS_STYLES.draft;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${s.bg} ${s.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${s.dot}`} />
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

function KpiRow({ items }: { items: { label: string; value: string | number; sub?: string }[] }) {
  return (
    <div className="flex flex-wrap gap-px bg-gray-100 rounded-xl overflow-hidden border border-gray-100">
      {items.map(({ label, value, sub }) => (
        <div key={label} className="flex-1 min-w-[80px] bg-white px-4 py-3">
          <p className="text-[10px] uppercase tracking-wider text-gray-400 font-medium mb-0.5">{label}</p>
          <p className="text-xl font-semibold text-gray-900 leading-none">
            {value}
            {sub && <span className="text-xs font-normal text-gray-400 ml-0.5">{sub}</span>}
          </p>
        </div>
      ))}
    </div>
  );
}

/* ─── expanded campaign detail ─────────────────────────────────── */
function CampaignDetail({ id }: { id: string }) {
  const { data: report, isLoading } = useQuery({
    queryKey: ['campaign-report', id],
    queryFn: () => getCampaignReport(id),
    enabled: !!id,
  });

  if (isLoading) return <div className="py-8 flex justify-center"><PageLoader /></div>;
  if (!report)   return <div className="py-6 text-center text-sm text-gray-400">No data available</div>;

  return (
    <div className="px-8 py-5 space-y-4 bg-gray-50/70 border-t border-gray-100">
      <KpiRow items={[
        { label: 'Total contacts',  value: (report.total_contacts      ?? 0).toLocaleString() },
        { label: 'Successful',      value: (report.successful_contacts ?? 0).toLocaleString() },
        { label: 'Duplicates',      value: (report.duplicate_contacts  ?? 0).toLocaleString() },
        { label: 'Attempted',       value: (report.attempted           ?? 0).toLocaleString() },
        { label: 'Connected',       value: (report.connected           ?? 0).toLocaleString() },
        { label: 'Completed',       value: (report.completed_total     ?? 0).toLocaleString() },
        { label: 'DNC',             value: (report.dnc                 ?? 0).toLocaleString() },
      ]} />

      <KpiRow items={[
        { label: 'Avg preview',        value: report.avg_preview_duration_sec ?? 0, sub: 's' },
        { label: 'Avg talk time',      value: report.avg_talk_time_sec        ?? 0, sub: 's' },
        { label: 'Avg wrap-up',        value: report.avg_wrapup_duration_sec  ?? 0, sub: 's' },
        { label: 'Avg total handling', value: report.avg_total_handling_sec   ?? 0, sub: 's' },
      ]} />

      {report.dispositions?.length > 0 && (
        <div>
          <p className="text-[10px] uppercase tracking-wider text-gray-400 font-medium mb-2">Disposition breakdown</p>
          <div className="space-y-2">
            {report.dispositions.map((d: any) => {
              const pct = Math.round((d.count / Math.max(report.total_contacts, 1)) * 100);
              return (
                <div key={d.code} className="flex items-center gap-3">
                  <span className="text-xs text-gray-600 w-40 flex-shrink-0 truncate">{d.label}</span>
                  <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full rounded-full bg-[#E8470A]" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="text-xs font-medium text-gray-700 w-7 text-right">{d.count}</span>
                  <span className="text-xs text-gray-400 w-8 text-right">{pct}%</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── page ─────────────────────────────────────────────────────── */
export default function ReportsPage() {
  const [expandedId, setExpandedId]     = useState<string | null>(null);
  const [campSearch, setCampSearch]     = useState('');
  const [dateFrom, setDateFrom]         = useState('');
  const [dateTo, setDateTo]             = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [previewFilter, setPreviewFilter] = useState('');
  const [callFilter, setCallFilter]       = useState('');
  const [intSearch, setIntSearch]         = useState('');

  const { data: campaigns } = useQuery({ queryKey: ['campaigns'], queryFn: getCampaigns });
  const { data: interactions, isLoading: loadInt } = useQuery({
    queryKey: ['interactions', previewFilter, callFilter],
    queryFn: () => getInteractions({
      preview_action: previewFilter || undefined,
      call_status:    callFilter    || undefined,
      per_page: 100,
    }),
  });

  const campList: any[] = useMemo(() => {
    let rows: any[] = campaigns?.data || [];
    const q = campSearch.trim().toLowerCase();
    if (q)            rows = rows.filter((c: any) => c.name?.toLowerCase().includes(q));
    if (statusFilter) rows = rows.filter((c: any) => c.status === statusFilter);
    return rows;
  }, [campaigns, campSearch, statusFilter]);

  const filteredInteractions = useMemo(() => {
    const rows = interactions?.data || [];
    const q = intSearch.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((r: any) => {
      const name  = `${r.first_name || ''} ${r.last_name || ''}`.toLowerCase();
      const phone = (r.phone_number || '').toLowerCase();
      const agent = (r.agent_name   || '').toLowerCase();
      return name.includes(q) || phone.includes(q) || agent.includes(q);
    });
  }, [interactions, intSearch]);

  /* ── shared input styles ── */
  const inputCls = 'py-1.5 text-sm border border-gray-200 rounded-lg bg-white text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-[#E8470A] focus:border-[#E8470A]';

  return (
    <div className="flex flex-col h-full w-full animate-fade-up overflow-hidden">

      {/* ── sticky toolbar ─────────────────────────────────────── */}
      <div className="flex-shrink-0 sticky top-0 z-20 bg-white border-b border-gray-100 px-6 md:px-8 pt-5 pb-4 space-y-3">
        <div>
          <h1 className="text-xl font-bold text-[#1A0F00]">Reports</h1>
          <p className="text-xs text-gray-400 mt-0.5">Campaign performance &amp; interaction log</p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* campaign search */}
          <div className="relative flex-1 min-w-[160px] max-w-xs">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            <input className={`w-full pl-8 pr-3 ${inputCls}`} placeholder="Search campaigns…" value={campSearch} onChange={e => setCampSearch(e.target.value)} />
          </div>

          {/* date range */}
          <div className="relative">
            <Calendar className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" />
            <input type="date" className={`pl-8 pr-2 ${inputCls}`} value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
          </div>
          <span className="text-gray-300 text-sm select-none">—</span>
          <div className="relative">
            <Calendar className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" />
            <input type="date" className={`pl-8 pr-2 ${inputCls}`} value={dateTo} onChange={e => setDateTo(e.target.value)} />
          </div>

          {/* status filter */}
          <div className="relative">
            <Filter className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" />
            <select className={`pl-8 pr-6 ${inputCls} appearance-none`} value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
              <option value="">All statuses</option>
              <option value="active">Active</option>
              <option value="paused">Paused</option>
              <option value="draft">Draft</option>
              <option value="completed">Completed</option>
            </select>
          </div>
        </div>
      </div>

      {/* ── scrollable body ─────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto px-6 md:px-8 py-6 space-y-8">

        {/* ── Campaign report ─── */}
        <section>
          <p className="text-[10px] uppercase tracking-widest font-semibold text-gray-400 mb-3">Campaign report</p>
          <div className="rounded-xl border border-gray-100 overflow-hidden bg-white">

            {/* col headers */}
            <div className="grid gap-4 px-5 py-2.5 bg-gray-50 border-b border-gray-100"
              style={{ gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr 36px' }}>
              {['Campaign', 'Status', 'Contacts', 'Connected', 'Completed', ''].map(h => (
                <span key={h} className="text-[10px] uppercase tracking-wider font-semibold text-gray-400">{h}</span>
              ))}
            </div>

            {campList.length === 0 && (
              <div className="py-16 flex flex-col items-center gap-2 text-gray-300">
                <BarChart2 className="w-8 h-8" />
                <p className="text-sm text-gray-400">No campaigns found</p>
              </div>
            )}

            {campList.map((c: any, idx: number) => {
              const isOpen = expandedId === String(c.id);
              return (
                <div key={c.id} className={idx !== 0 ? 'border-t border-gray-100' : ''}>
                  <button
                    onClick={() => setExpandedId(isOpen ? null : String(c.id))}
                    className={`w-full grid gap-4 items-center px-5 py-3.5 text-left transition-colors ${isOpen ? 'bg-orange-50/40' : 'hover:bg-gray-50/60'}`}
                    style={{ gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr 36px' }}
                  >
                    <div className="min-w-0">
                      <p className={`text-sm font-medium truncate ${isOpen ? 'text-[#E8470A]' : 'text-gray-800'}`}>{c.name}</p>
                      {c.description && <p className="text-xs text-gray-400 truncate mt-0.5">{c.description}</p>}
                    </div>
                    <div>{c.status ? <StatusPill status={c.status} /> : <span className="text-gray-400">—</span>}</div>
                    <span className="text-sm text-gray-700">{(c.total_contacts ?? 0).toLocaleString()}</span>
                    <span className="text-sm text-gray-700">{c.connected      != null ? c.connected.toLocaleString()       : '—'}</span>
                    <span className="text-sm text-gray-700">{c.completed_total != null ? c.completed_total.toLocaleString() : '—'}</span>
                    <span className="flex items-center justify-center">
                      {isOpen
                        ? <ChevronUp   className="w-4 h-4 text-[#E8470A]" />
                        : <ChevronDown className="w-4 h-4 text-gray-400"  />}
                    </span>
                  </button>

                  {isOpen && <CampaignDetail id={String(c.id)} />}
                </div>
              );
            })}
          </div>
        </section>

        {/* ── Interaction log ─── */}
        <section>
          <div className="flex items-center justify-between gap-3 flex-wrap mb-3">
            <p className="text-[10px] uppercase tracking-widest font-semibold text-gray-400">Interaction log</p>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative">
                <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                <input className={`pl-8 pr-3 w-52 ${inputCls}`} placeholder="Search contact, phone, agent…" value={intSearch} onChange={e => setIntSearch(e.target.value)} />
              </div>
              <select className={`px-3 ${inputCls} appearance-none`} value={previewFilter} onChange={e => setPreviewFilter(e.target.value)}>
                <option value="">All actions</option>
                <option value="accepted">Accepted</option>
                <option value="rejected">Rejected</option>
              </select>
              <select className={`px-3 ${inputCls} appearance-none`} value={callFilter} onChange={e => setCallFilter(e.target.value)}>
                <option value="">All call statuses</option>
                <option value="connected">Connected</option>
                <option value="no_answer">No Answer</option>
                <option value="busy">Busy</option>
                <option value="voicemail">Voicemail</option>
              </select>
            </div>
          </div>

          <div className="rounded-xl border border-gray-100 overflow-hidden bg-white">
            {loadInt ? (
              <div className="py-12 flex justify-center"><PageLoader /></div>
            ) : (
              <>
                <div className="grid gap-3 px-5 py-2.5 bg-gray-50 border-b border-gray-100"
                  style={{ gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr 1fr 1.2fr 1.5fr' }}>
                  {['Contact','Agent','Action','Call status','Talk time','Total handle','Disposition','Given at'].map(h => (
                    <span key={h} className="text-[10px] uppercase tracking-wider font-semibold text-gray-400">{h}</span>
                  ))}
                </div>

                {filteredInteractions.length === 0 && (
                  <div className="py-12 text-center text-sm text-gray-400">
                    {intSearch ? `No results for "${intSearch}"` : 'No interactions found'}
                  </div>
                )}

                {filteredInteractions.map((r: any, idx: number) => (
                  <div
                    key={r.interaction_id}
                    className={`grid gap-3 items-center px-5 py-3 text-sm transition-colors hover:bg-gray-50/60 ${idx !== 0 ? 'border-t border-gray-100' : ''}`}
                    style={{ gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr 1fr 1.2fr 1.5fr' }}
                  >
                    <div className="min-w-0">
                      <p className="font-medium text-gray-900 truncate">{r.first_name} {r.last_name}</p>
                      <p className="text-xs text-gray-400 truncate">{r.phone_number}</p>
                    </div>
                    <span className="text-gray-600 truncate">{r.agent_name || '—'}</span>
                    <span>{r.preview_action ? <StatusBadge status={r.preview_action} /> : <span className="text-gray-400">—</span>}</span>
                    <span>{r.call_status   ? <StatusBadge status={r.call_status}   /> : <span className="text-gray-400">—</span>}</span>
                    <span className="text-gray-600">{r.talk_time_sec      ? `${r.talk_time_sec}s`      : '—'}</span>
                    <span className="text-gray-600">{r.total_handling_sec ? `${r.total_handling_sec}s` : '—'}</span>
                    <span>{r.disposition_code_label ? <Badge label={r.disposition_code_label} color="blue" /> : <span className="text-gray-400">—</span>}</span>
                    <span className="text-gray-500 text-xs">{new Date(r.given_at).toLocaleString()}</span>
                  </div>
                ))}
              </>
            )}
          </div>
        </section>

      </div>
    </div>
  );
}