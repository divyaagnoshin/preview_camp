import { useMemo, useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getCampaigns, getJobs } from '../../api/client';
import { Download, Search, PieChart } from 'lucide-react';
import {
  ColDef, ColPicker, TableHeader, TableFooter, StatusPill, CellText, exportCSV,
  loadSavedCols, saveCols, MiniTable, FilterBar
} from './report-utils';

const ACCENT = '#6366f1';
const GRAD = 'linear-gradient(135deg,#1e1b4b 0%,#4338ca 50%,#7c3aed 100%)';

function fmt(v: any) { return v == null || v === '' ? '—' : String(v); }
function fmtNum(v: any) { return v == null ? '—' : Number(v).toLocaleString(); }
function fmtPct(v: any) { return v == null ? '—' : `${Number(v).toFixed(1)}%`; }
function fmtDate(v: any) { return v ? new Date(v).toLocaleDateString() : '—'; }

const DEFAULT_COLS: ColDef[] = [
  { key: 'name',               label: 'Campaign Name',   visible: true,  get: r => fmt(r.name) },
  { key: 'status',             label: 'Status',          visible: true,  get: r => fmt(r.status) },
  { key: 'job_status',         label: 'Job Status',      visible: true,  get: r => fmt(r.job_status) },
  { key: 'job_run_number',     label: 'Run #',           visible: true,  get: r => fmtNum(r.job_run_number) },
  { key: 'total_contacts',     label: 'Total Contacts',  visible: true,  get: r => fmtNum(r.total_contacts) },
  { key: 'processed_contacts', label: 'Processed',       visible: true,  get: r => fmtNum(r.processed_contacts) },
  { key: 'excluded_contacts',  label: 'Excluded',        visible: true,  get: r => fmtNum(r.excluded_contacts) },
  { key: 'prcnt_complete',     label: '% Complete',      visible: true,  get: r => fmtPct(r.prcnt_complete) },
  { key: 'start_time',         label: 'Start Time',      visible: true,  get: r => fmtDate(r.start_time) },
  { key: 'end_time',           label: 'End Time',        visible: false, get: r => fmtDate(r.end_time) },
  { key: 'caller_id',          label: 'Caller ID',       visible: false, get: r => fmt(r.caller_id) },
  { key: 'schedule_type',      label: 'Schedule Type',   visible: false, get: r => fmt(r.schedule_type) },
  { key: 'max_attempts',       label: 'Max Attempts',    visible: false, get: r => fmtNum(r.max_attempts) },
  { key: 'wrapup_time_sec',    label: 'Wrapup (s)',      visible: false, get: r => fmtNum(r.wrapup_time_sec) },
  { key: 'auto_dial_delay_sec',label: 'Dial Delay (s)',  visible: false, get: r => fmtNum(r.auto_dial_delay_sec) },
  { key: 'start_date',         label: 'Start Date',      visible: false, get: r => fmtDate(r.start_date) },
  { key: 'end_date',           label: 'End Date',        visible: false, get: r => fmtDate(r.end_date) },
  { key: 'created_at',         label: 'Created At',      visible: false, get: r => fmtDate(r.created_at) },
];


// ── Compact Donut (horizontal: donut left, legend right) ─────────────────────
function BigDonut({
  title, data, total, subtitle,
}: {
  title: string; subtitle?: string;
  data: { label: string; count: number; color: string }[];
  total: number;
}) {
  const [hov, setHov] = useState<string | null>(null);
  const R = 62, ri = 38, CX = 72, CY = 72;
  let angle = -Math.PI / 2;


  const arcs = data.map(d => {
    const sweep = total > 0 ? (d.count / total) * 2 * Math.PI : 0;
    const ea = angle + sweep;
    const path = sweep > 0.01 ? [
      `M${CX + R * Math.cos(angle)},${CY + R * Math.sin(angle)}`,
      `A${R},${R} 0 ${sweep > Math.PI ? 1 : 0},1 ${CX + R * Math.cos(ea)},${CY + R * Math.sin(ea)}`,
      `L${CX + ri * Math.cos(ea)},${CY + ri * Math.sin(ea)}`,
      `A${ri},${ri} 0 ${sweep > Math.PI ? 1 : 0},0 ${CX + ri * Math.cos(angle)},${CY + ri * Math.sin(angle)}`,
      'Z',
    ].join(' ') : '';
    angle = ea;
    return { ...d, path, pct: total > 0 ? ((d.count / total) * 100).toFixed(1) : '0' };
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 0 }}>
      <p style={{ fontSize: 14, fontWeight: 800, color: '#1e293b', margin: '0 0 10px', letterSpacing: '-0.01em' }}>{title}</p>
      {subtitle && <p style={{ fontSize: 11, color: '#94a3b8', margin: '-6px 0 10px', fontWeight: 500 }}>{subtitle}</p>}
      {/* Horizontal: donut + legend side by side */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 18, width: '100%' }}>
        {/* Donut SVG */}
        <svg width={144} height={144} style={{ flexShrink: 0 }}>
          {total === 0
            ? <circle cx={CX} cy={CY} r={(R + ri) / 2} fill="none" stroke="#e2e8f0" strokeWidth={R - ri} />
            : arcs.map(a => a.path && (
              <path key={a.label} d={a.path} fill={a.color}
                stroke="#fff" strokeWidth={2}
                opacity={hov && hov !== a.label ? 0.2 : 1}
                onMouseEnter={() => setHov(a.label)}
                onMouseLeave={() => setHov(null)}
                style={{ cursor: 'pointer', transition: 'opacity 0.18s' }}
              />
            ))
          }
          <text x={CX} y={CY - 10} textAnchor="middle" fontSize={24} fontWeight={900} fill="#1e293b">{total}</text>
          <text x={CX} y={CY + 9} textAnchor="middle" fontSize={10} fill="#94a3b8" fontWeight={700}>TOTAL</text>
          {hov && (() => {
            const a = arcs.find(x => x.label === hov);
            return a ? (
              <>
                <text x={CX} y={CY + 26} textAnchor="middle" fontSize={10} fill={a.color} fontWeight={700}>{a.label}</text>
                <text x={CX} y={CY + 40} textAnchor="middle" fontSize={9} fill="#94a3b8">{a.pct}%</text>
              </>
            ) : null;
          })()}
        </svg>
        {/* Legend */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, flex: 1, minWidth: 0 }}>
          {arcs.map(a => (
            <div key={a.label}
              onMouseEnter={() => setHov(a.label)}
              onMouseLeave={() => setHov(null)}
              style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '5px 10px', borderRadius: 8,
                background: hov === a.label ? `${a.color}12` : '#f8fafc',
                border: `1.5px solid ${hov === a.label ? a.color + '40' : '#f1f5f9'}`,
                cursor: 'default', transition: 'all 0.15s',
                opacity: hov && hov !== a.label ? 0.4 : 1,
              }}>
              <span style={{ width: 10, height: 10, borderRadius: '50%', background: a.color, flexShrink: 0, boxShadow: `0 0 0 2px ${a.color}22` }} />
              <span style={{ fontSize: 12, color: '#334155', fontWeight: 600, flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.label}</span>
              <span style={{ fontSize: 15, fontWeight: 900, color: a.color }}>{a.count}</span>
              <span style={{ fontSize: 11, color: '#94a3b8', fontWeight: 600, minWidth: 36, textAlign: 'right' }}>{a.pct}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Big Line Chart ────────────────────────────────────────────────────────────
function BigLineChart({ rows }: { rows: any[] }) {
  const [tip, setTip] = useState<{ x: number; y: number; html: string } | null>(null);
  const [hovIdx, setHovIdx] = useState<number | null>(null);

  const data = rows.slice(0, 15).map(r => ({
    name: (r.name || '—').length > 16 ? r.name.slice(0, 15) + '…' : r.name,
    fullName: r.name || '—',
    pct: Math.min(100, Math.max(0, parseFloat(r.prcnt_complete) || 0)),
    attempt: r.total_contacts > 0
      ? Math.min(100, ((r.processed_contacts || 0) / r.total_contacts) * 100) : 0,
  }));

  const W = 760, H = 320, PL = 56, PR = 20, PT = 20, PB = 80;
  const cW = W - PL - PR, cH = H - PT - PB;
  const n = data.length;
  if (n === 0) return (
    <div style={{ textAlign: 'center', padding: '80px 0', fontSize: 16, color: '#94a3b8' }}>No campaign data available</div>
  );

  const xOf = (i: number) => n === 1 ? cW / 2 : (i / (n - 1)) * cW;
  const yOf = (v: number) => cH - (v / 100) * cH;
  const yTicks = [0, 20, 40, 60, 80, 100];

  const pctLine = data.map((d, i) => `${i === 0 ? 'M' : 'L'}${PL + xOf(i)},${PT + yOf(d.pct)}`).join(' ');
  const attLine = data.map((d, i) => `${i === 0 ? 'M' : 'L'}${PL + xOf(i)},${PT + yOf(d.attempt)}`).join(' ');

  return (
    <div style={{ position: 'relative', width: '100%' }}>
      {/* Legend */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 32, marginBottom: 16 }}>
        {[
          { color: '#10b981', label: 'Percent Complete (%)', dash: false },
          { color: '#f43f5e', label: 'Unique Attempt to List (%)', dash: true },
        ].map(l => (
          <span key={l.label} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: '#475569', fontWeight: 700 }}>
            <svg width={32} height={14}>
              <line x1={0} y1={7} x2={32} y2={7} stroke={l.color} strokeWidth={2.5} strokeDasharray={l.dash ? '5,4' : ''} />
              <circle cx={16} cy={7} r={4} fill={l.color} />
            </svg>
            {l.label}
          </span>
        ))}
      </div>

      <div style={{ overflowX: 'auto' }}>
        <svg width={W} height={H} style={{ display: 'block', minWidth: '100%' }}>
          <defs>
            <linearGradient id="pctFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10b981" stopOpacity={0.25} />
              <stop offset="100%" stopColor="#10b981" stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id="attFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f43f5e" stopOpacity={0.18} />
              <stop offset="100%" stopColor="#f43f5e" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <g>
            {/* Y grid + labels */}
            {yTicks.map(t => (
              <g key={t}>
                <line x1={PL} y1={PT + yOf(t)} x2={PL + cW} y2={PT + yOf(t)}
                  stroke={t === 0 ? '#cbd5e1' : '#f1f5f9'} strokeWidth={t === 0 ? 1.5 : 1} />
                <text x={PL - 10} y={PT + yOf(t) + 5} textAnchor="end" fontSize={13} fill="#94a3b8" fontWeight={600}>{t}%</text>
              </g>
            ))}

            {/* Filled areas */}
            <path d={`${pctLine} L${PL + xOf(n - 1)},${PT + cH} L${PL},${PT + cH} Z`} fill="url(#pctFill)" />
            <path d={`${attLine} L${PL + xOf(n - 1)},${PT + cH} L${PL},${PT + cH} Z`} fill="url(#attFill)" />

            {/* Lines */}
            <path d={pctLine} fill="none" stroke="#10b981" strokeWidth={3} strokeLinejoin="round" strokeLinecap="round" />
            <path d={attLine} fill="none" stroke="#f43f5e" strokeWidth={3} strokeLinejoin="round" strokeLinecap="round" strokeDasharray="7,5" />

            {/* Data points + labels */}
            {data.map((d, i) => {
              const isHov = hovIdx === i;
              return (
                <g key={i}
                  onMouseEnter={e => {
                    setHovIdx(i);
                    setTip({ x: e.clientX, y: e.clientY, html: `${d.fullName}\n% Complete: ${d.pct.toFixed(1)}%\nUnique Attempt: ${d.attempt.toFixed(1)}%` });
                  }}
                  onMouseLeave={() => { setHovIdx(null); setTip(null); }}
                  style={{ cursor: 'pointer' }}
                >
                  {isHov && (
                    <line x1={PL + xOf(i)} y1={PT} x2={PL + xOf(i)} y2={PT + cH}
                      stroke="#e2e8f0" strokeWidth={1.5} strokeDasharray="4,3" />
                  )}
                  <circle cx={PL + xOf(i)} cy={PT + yOf(d.pct)} r={isHov ? 8 : 5}
                    fill="#10b981" stroke="#fff" strokeWidth={2.5} style={{ transition: 'r 0.12s' }} />
                  <circle cx={PL + xOf(i)} cy={PT + yOf(d.attempt)} r={isHov ? 8 : 5}
                    fill="#f43f5e" stroke="#fff" strokeWidth={2.5} style={{ transition: 'r 0.12s' }} />

                  {/* Value labels on hover */}
                  {isHov && (
                    <>
                      <text x={PL + xOf(i) + 12} y={PT + yOf(d.pct) + 4} fontSize={12} fontWeight={800} fill="#10b981">{d.pct.toFixed(1)}%</text>
                      <text x={PL + xOf(i) + 12} y={PT + yOf(d.attempt) + 4} fontSize={12} fontWeight={800} fill="#f43f5e">{d.attempt.toFixed(1)}%</text>
                    </>
                  )}

                  {/* X-axis label */}
                  <text x={PL + xOf(i)} y={PT + cH + 20} textAnchor="middle" fontSize={12}
                    fill={isHov ? '#4338ca' : '#64748b'} fontWeight={isHov ? 800 : 500}
                    transform={n > 5 ? `rotate(-38, ${PL + xOf(i)}, ${PT + cH + 20})` : ''}>
                    {d.name}
                  </text>
                </g>
              );
            })}
          </g>
        </svg>
      </div>

      {tip && (
        <div style={{
          position: 'fixed', left: tip.x + 14, top: tip.y - 12,
          background: '#1e1b4b', color: '#fff', borderRadius: 10,
          padding: '10px 16px', fontSize: 13, lineHeight: 1.8,
          boxShadow: '0 8px 32px rgba(0,0,0,0.35)', pointerEvents: 'none', zIndex: 9999, whiteSpace: 'pre-line',
          borderLeft: '3px solid #6366f1',
        }}>
          {tip.html}
        </div>
      )}
    </div>
  );
}

// ── Chart View ────────────────────────────────────────────────────────────────
function ActiveCampaignsChartView({ rows }: { rows: any[] }) {
  const statusMap: Record<string, number> = {};
  rows.forEach(r => {
    const s = (r.job_status || r.status || 'other').toLowerCase();
    const key = ['running', 'filtering', 'paused', 'callback'].includes(s) ? s : 'other';
    statusMap[key] = (statusMap[key] || 0) + 1;
  });
  const statusData = [
    { label: 'Running',   count: statusMap['running']   || 0, color: '#10b981' },
    { label: 'Filtering', count: statusMap['filtering'] || 0, color: '#3b82f6' },
    { label: 'Paused',    count: statusMap['paused']    || 0, color: '#f97316' },
    { label: 'Callback',  count: statusMap['callback']  || 0, color: '#06b6d4' },
    { label: 'Other',     count: statusMap['other']     || 0, color: '#94a3b8' },
  ];

  const totalContacts = rows.reduce((a, r) => a + (r.total_contacts || 0), 0);
  const totalProcessed = rows.reduce((a, r) => a + (r.processed_contacts || 0), 0);
  const avgPct = rows.length ? rows.reduce((a, r) => a + (parseFloat(r.prcnt_complete) || 0), 0) / rows.length : 0;

  const kpis = [
    { label: 'Total Campaigns', value: rows.length, color: '#6366f1', bg: '#eef2ff' },
    { label: 'Total Contacts',  value: totalContacts.toLocaleString(), color: '#7c3aed', bg: '#f5f3ff' },
    { label: 'Processed',       value: totalProcessed.toLocaleString(), color: '#059669', bg: '#ecfdf5' },
    { label: 'Avg % Complete',  value: `${avgPct.toFixed(1)}%`, color: '#d97706', bg: '#fffbeb' },
  ];

  return (
    <div style={{ background: '#f8fafc', padding: '28px 32px 36px' }}>
      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16, marginBottom: 36 }}>
        {kpis.map(k => (
          <div key={k.label} style={{
            background: '#fff', borderRadius: 14, padding: '20px 22px',
            border: `1.5px solid ${k.color}20`,
            boxShadow: `0 2px 16px ${k.color}10`,
          }}>
            <p style={{ margin: 0, fontSize: 30, fontWeight: 900, color: k.color, lineHeight: 1 }}>{k.value}</p>
            <p style={{ margin: '6px 0 0', fontSize: 12, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.07em' }}>{k.label}</p>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: 28, alignItems: 'start' }}>
        {/* Left: Donut */}
        <div style={{ background: '#fff', borderRadius: 16, padding: '22px 20px', boxShadow: '0 2px 16px rgba(99,102,241,0.08)', border: '1.5px solid #e0e7ff' }}>
          <BigDonut title="Campaign Status" subtitle="Distribution by job status" data={statusData} total={rows.length} />
        </div>

        {/* Right: Line Chart */}
        <div style={{ background: '#fff', borderRadius: 16, padding: '28px 24px', boxShadow: '0 2px 16px rgba(99,102,241,0.08)', border: '1.5px solid #e0e7ff' }}>
          <p style={{ fontSize: 16, fontWeight: 800, color: '#1e293b', margin: '0 0 4px', letterSpacing: '-0.01em' }}>Completion Progress</p>
          <p style={{ fontSize: 12, color: '#94a3b8', margin: '0 0 20px', fontWeight: 500 }}>% Complete & Unique Attempt per campaign</p>
          <BigLineChart rows={rows} />
        </div>
      </div>
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function ActiveCampaignsReport({ isMini, onExpand, miniTitle, pal }: { isMini?: boolean; onExpand?: () => void; miniTitle?: string; pal?: any } = {}) {
  const [cols, setCols] = useState<ColDef[]>(() => loadSavedCols('active-campaigns', DEFAULT_COLS));
  const [sortKey, setSortKey] = useState('start_time');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [globalQ, setGlobalQ] = useState('');
  const [colFilters, setColFilters] = useState<Record<string, string[]>>({});
  const [showChart, setShowChart] = useState(false);

  const { data: campData } = useQuery({ queryKey: ['campaigns'], queryFn: getCampaigns });
  const { data: jobData }  = useQuery({ queryKey: ['jobs-all'], queryFn: () => getJobs({ per_page: 500 }) });

  useEffect(() => {
    function onStorage() { setCols(loadSavedCols('active-campaigns', DEFAULT_COLS)); }
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const allRows = useMemo(() => {
    const campaigns: any[] = (campData?.data || []).filter((c: any) => c.status === 'active');
    const jobs: any[] = jobData?.data || [];
    return campaigns.map(c => {
      const job: any = jobs.find((j: any) => j.campaign_id === c.id) || {};
      return {
        ...c,
        job_status: job.status, job_run_number: job.job_run_number,
        total_contacts: job.total_contacts ?? c.total_contacts,
        processed_contacts: job.processed_contacts, excluded_contacts: job.excluded_contacts,
        prcnt_complete: job.prcnt_complete, start_time: job.start_time, end_time: job.end_time,
      };
    });
  }, [campData, jobData]);

  const rows = useMemo(() => {
    let result = allRows;
    const q = globalQ.trim().toLowerCase();
    if (q) result = result.filter(r => cols.filter(c => c.visible).some(c => c.get(r).toLowerCase().includes(q)));
    Object.entries(colFilters).forEach(([key, vals]) => {
      if (!vals || vals.length === 0) return;
      const col = cols.find(c => c.key === key);
      if (col) result = result.filter(r => vals.some(v => col.get(r).toLowerCase() === v.toLowerCase()));
    });
    return [...result].sort((a, b) => {
      const col = cols.find(c => c.key === sortKey);
      const av = col ? col.get(a) : '', bv = col ? col.get(b) : '';
      return sortDir === 'desc'
        ? bv.localeCompare(av, undefined, { numeric: true })
        : av.localeCompare(bv, undefined, { numeric: true });
    });
  }, [allRows, globalQ, colFilters, sortKey, sortDir, cols]);

  const visCols = cols.filter(c => c.visible);
  function toggleSort(key: string) {
    if (sortKey === key) setSortDir(d => d === 'desc' ? 'asc' : 'desc');
    else { setSortKey(key); setSortDir('desc'); }
  }

  if (isMini) {
    const miniCols = ['Campaign Name', 'Status', 'Total Contacts', '% Complete'];
    const activeCols = DEFAULT_COLS.filter(c => miniCols.includes(c.label));
    const miniRows = rows.slice(0, 5).map(r => ({ cells: activeCols.map(c => c.get(r)) }));
    return <MiniTable title={miniTitle || 'Active Campaigns'} cols={activeCols.map(c => c.label)} rows={miniRows} pal={pal} onExpand={onExpand!} emptyMsg="No campaigns found" />;
  }

  return (
    <div style={{ borderRadius: 16, boxShadow: '0 4px 32px rgba(99,102,241,0.15)', border: '1.5px solid #c7d2fe', overflow: 'hidden' }}>

      {/* ── Header ── */}
      <div style={{ position: 'relative', zIndex: 99, background: GRAD, padding: '18px 22px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
          <div>
            <p style={{ fontSize: 15, fontWeight: 800, color: '#fff', margin: 0, letterSpacing: '-0.01em' }}>Active Campaigns</p>
            <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.6)', margin: '2px 0 0' }}>{rows.length} record{rows.length !== 1 ? 's' : ''}</p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            {!showChart && (
              <div style={{ position: 'relative' }}>
                <Search style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', width: 13, height: 13, color: 'rgba(255,255,255,0.5)', pointerEvents: 'none' }} />
                <input value={globalQ} onChange={e => setGlobalQ(e.target.value)} placeholder="Search all columns…"
                  style={{ height: 34, paddingLeft: 30, paddingRight: 10, fontSize: 12.5, borderRadius: 9, border: '1.5px solid rgba(255,255,255,0.22)', background: 'rgba(255,255,255,0.1)', color: '#fff', outline: 'none', width: 200 }} />
              </div>
            )}
            {!showChart && (
              <ColPicker cols={cols} onChange={newCols => { setCols(newCols); saveCols('active-campaigns', newCols); }} accentColor={ACCENT} />
            )}
            {/* Chart toggle — top right */}
            <button
              onClick={() => setShowChart(v => !v)}
              title={showChart ? 'Switch to Table' : 'Switch to Chart'}
              style={{
                width: 36, height: 36, borderRadius: 9, border: 'none', cursor: 'pointer',
                background: showChart ? '#fff' : 'rgba(255,255,255,0.15)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: showChart ? '#6366f1' : '#fff', flexShrink: 0, transition: 'all 0.18s',
                boxShadow: showChart ? '0 2px 12px rgba(0,0,0,0.15)' : 'none',
              }}
            >
              <PieChart size={18} />
            </button>
            <button onClick={() => exportCSV(rows, cols, 'active-campaigns.csv')}
              style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 14px', borderRadius: 9, border: '1.5px solid rgba(255,255,255,0.25)', background: 'rgba(255,255,255,0.12)', color: '#fff', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}>
              <Download size={13} /> Export CSV
            </button>
          </div>
        </div>
      </div>

      {/* ── Chart View (replaces table) ── */}
      {showChart && <ActiveCampaignsChartView rows={rows} />}

      {/* ── Table View ── */}
      {!showChart && (
        <>
          <div style={{ position: 'relative', zIndex: 1, overflowX: 'auto', background: '#fff', width: '100%' }}>
            <div style={{ minWidth: visCols.length * 200 }}>
              <FilterBar cols={visCols} rows={allRows} colFilters={colFilters}
                onFilter={(k, v) => setColFilters(f => ({ ...f, [k]: v }))}
                onClearAll={() => setColFilters({})} accentColor={ACCENT} />
              <div style={{ position: 'relative', zIndex: 10, background: GRAD, padding: '10px 22px 18px' }}>
                <TableHeader visCols={visCols} sortKey={sortKey} sortDir={sortDir} onSort={toggleSort} accentColor={ACCENT} />
              </div>
              <div style={{ maxHeight: 520, overflowY: 'auto', overflowX: 'hidden' }}>
                {rows.length === 0 ? (
                  <div style={{ padding: '56px 0', textAlign: 'center', fontSize: 14, color: '#94a3b8' }}>No campaigns found</div>
                ) : rows.map((r, idx) => (
                  <div key={r.id} style={{
                    display: 'grid', gridTemplateColumns: `repeat(${visCols.length}, minmax(180px, 1fr))`,
                    gap: 20, padding: '11px 22px', borderBottom: '1px solid #f1f5f9',
                    background: idx % 2 === 0 ? '#fff' : '#f8faff',
                    alignItems: 'center', transition: 'background 0.1s',
                  }}
                    onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = '#eef2ff'}
                    onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = idx % 2 === 0 ? '#fff' : '#f8faff'}
                  >
                    {visCols.map(c => (
                      <div key={c.key} style={{ minWidth: 0, overflow: 'hidden', maxWidth: '100%' }}>
                        {(c.key === 'status' || c.key === 'job_status') && r[c.key]
                          ? <StatusPill status={r[c.key]} />
                          : <CellText>{c.get(r)}</CellText>}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>
          <TableFooter total={rows.length} sortLabel={cols.find(c => c.key === sortKey)?.label || sortKey} sortDir={sortDir} accentColor={ACCENT} />
        </>
      )}
    </div>
  );
}
