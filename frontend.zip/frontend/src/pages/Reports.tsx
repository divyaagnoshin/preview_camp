import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  getCampaigns, getInteractions,
  listAgentSessions, getJobs, getAgentLoginHistory,
} from '../api/client';
import {
  BarChart2, Phone, Users, ClipboardList, LogIn,
  CheckCircle, Clock, Settings, LayoutDashboard,
  TrendingUp, Activity,
} from 'lucide-react';

import ActiveCampaignsReport from './Reports/active-campaigns';
import StaffedAgentsReport from './Reports/staffed-agents';
import DispositionReport from './Reports/disposition-report';
import InteractionReport from './Reports/interaction-report';
import AgentLoginReport from './Reports/agent-login-repor';

import { PALETTE } from './Reports/report-utils';

const TABS = [
  { id: 'active-campaigns', label: 'Active Campaigns', icon: BarChart2, pal: PALETTE[0] },
  { id: 'staffed-agents', label: 'Staffed Agents', icon: Users, pal: PALETTE[1] },
  { id: 'disposition-report', label: 'Disposition Report', icon: ClipboardList, pal: PALETTE[2] },
  { id: 'interaction-report', label: 'Interaction Report', icon: Phone, pal: PALETTE[3] },
  { id: 'agent-login-report', label: 'Agent Login Report', icon: LogIn, pal: PALETTE[4] },
] as const;
type TabId = typeof TABS[number]['id'];

/* ── KPI Card ──────────────────────────────────────────────────────────── */
function KpiCard({ label, value, sub, icon: Icon, grad, accent }:
  { label: string; value: string | number; sub?: string; icon: any; grad: string; accent: string }) {
  return (
    <div style={{ borderRadius: 14, overflow: 'hidden', border: `1.5px solid ${accent}30`, boxShadow: `0 2px 14px ${accent}18`, background: '#fff' }}>
      <div style={{ background: grad, padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 34, height: 34, borderRadius: 10, background: 'rgba(255,255,255,0.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Icon size={16} color="#fff" />
        </div>
        <p style={{ fontSize: 22, fontWeight: 900, color: '#fff', margin: 0, fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>
          {value}{sub && <span style={{ fontSize: 12, fontWeight: 500, marginLeft: 3, opacity: 0.7 }}>{sub}</span>}
        </p>
      </div>
      <div style={{ padding: '8px 16px 10px' }}>
        <p style={{ fontSize: 10.5, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.09em', color: '#64748b', margin: 0 }}>{label}</p>
      </div>
    </div>
  );
}
/* ── Main Page ──────────────────────────────────────────────────────────── */
export default function ReportsPage() {
  const location = useLocation();
  const navigate = useNavigate();

  const pathTab = location.pathname.replace(/^\/reports\/?/, '') as TabId | '';
  const activeTab: TabId | null = (pathTab && TABS.some(t => t.id === pathTab)) ? pathTab as TabId : null;
  const isOverview = activeTab === null && !location.pathname.includes('/settings');
  const setActiveTab = (id: TabId | null) => navigate(id ? `/reports/${id}` : '/reports');

  // data queries
  const { data: campData } = useQuery({ queryKey: ['campaigns'], queryFn: getCampaigns });
  const { data: jobData } = useQuery({ queryKey: ['jobs-all'], queryFn: () => getJobs({ per_page: 500 }) });
  const { data: sessData } = useQuery({ queryKey: ['agent-sessions-live'], queryFn: listAgentSessions, refetchInterval: 15000 });
  const { data: intData } = useQuery({ queryKey: ['interactions-all'], queryFn: () => getInteractions({ per_page: 500 }) });
  const { data: loginHistory } = useQuery({ queryKey: ['agent-login-history'], queryFn: getAgentLoginHistory });

  // Read saved default campaign for disposition mini-table
  const [dispCampId] = React.useState<string>(() => localStorage.getItem('disposition_report_campaign') || '');

  const campaigns: any[] = campData?.data || [];
  const jobs: any[] = jobData?.data || [];
  const sessions: any[] = sessData?.data || [];
  const interactions: any[] = intData?.data || [];
  const historicSessions: any[] = loginHistory?.data || [];

  // KPI stats - match the same logic as individual reports
  const activeCamps = campaigns.filter((c: any) => c.status === 'active').length;
  // Staffed agents: only sessions that are actively logged in (no logout_at, not offline)
  const activeSessionsOnly = sessions.filter((s: any) => !s.logout_at && s.status !== 'offline');
  const liveAgents = activeSessionsOnly.length;
  const totalInts = interactions.length;
  const connected = interactions.filter((i: any) => i.call_status === 'connected').length;
  const avgTalk = interactions.length
    ? Math.round(interactions.reduce((a: number, i: any) => a + (i.talk_time_sec || 0), 0) / interactions.length)
    : 0;
  const totalProcessed = jobs.reduce((a: number, j: any) => a + (j.processed_contacts || 0), 0);



  return (
    <div style={{ padding: '24px 28px', fontFamily: '"DM Sans", sans-serif', minHeight: '100%', background: '#f8fafc' }}>

      {/* ── Page header ─────────────────────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 5 }}>
        <div>
          <h1 style={{
            fontSize: 24, fontWeight: 900, margin: 0, fontFamily: 'Sora, sans-serif', letterSpacing: '-0.02em',
            background: 'linear-gradient(135deg,#F4521E 0%,#F5A623 55%,#FFD080 100%)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>
            Reports
          </h1>

        </div>
        {/* Settings icon top-right */}
        <button
          onClick={() => navigate('/reports/settings')}
          title="Column Settings"
          style={{
            display: 'flex', alignItems: 'center', gap: 8,
            padding: '9px 16px', borderRadius: 11,
            border: '1.5px solid #e2e8f0',
            background: '#fff', color: '#475569',
            fontSize: 13, fontWeight: 700, cursor: 'pointer',
            boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
            transition: 'all 0.15s',
          }}
          onMouseEnter={e => (e.currentTarget as HTMLElement).style.borderColor = '#F4521E'}
          onMouseLeave={e => (e.currentTarget as HTMLElement).style.borderColor = '#e2e8f0'}
        >
          <Settings size={15} />
          Column Settings
        </button>
      </div>

      {/* ── Tab nav ─────────────────────────────────────────────────── */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 22, borderBottom: '2px solid #e2e8f0', flexWrap: 'wrap' }}>
        {/* Dashboard / Overview icon tab */}
        <button
          onClick={() => setActiveTab(null)}
          title="Dashboard Overview"
          style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '9px 16px', fontSize: 13, fontWeight: 700,
            borderRadius: '10px 10px 0 0', border: 'none', cursor: 'pointer',
            background: isOverview ? '#fff' : 'transparent',
            color: isOverview ? '#6366f1' : '#94a3b8',
            borderBottom: isOverview ? '2px solid #6366f1' : '2px solid transparent',
            marginBottom: -2, transition: 'all 0.15s',
          }}
        >
          <LayoutDashboard size={14} />
          <span>Dashboard</span>
        </button>

        {TABS.map(t => {
          const Icon = t.icon;
          const active = activeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '9px 16px', fontSize: 13, fontWeight: 700,
                borderRadius: '10px 10px 0 0', border: 'none', cursor: 'pointer',
                background: active ? '#fff' : 'transparent',
                color: active ? t.pal.accent : '#94a3b8',
                borderBottom: active ? `2px solid ${t.pal.accent}` : '2px solid transparent',
                marginBottom: -2, transition: 'all 0.15s',
              }}
            >
              <Icon size={13} />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* ── OVERVIEW / DASHBOARD ───────────────────────────────────── */}
      {isOverview && (
        <>
          {/* KPI row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 12, marginBottom: 22 }}>
            <KpiCard label="Active Campaigns" value={activeCamps} icon={BarChart2} grad={PALETTE[0].grad} accent={PALETTE[0].accent} />
            <KpiCard label="Live Agents" value={liveAgents} icon={Users} grad={PALETTE[1].grad} accent={PALETTE[1].accent} />
            <KpiCard label="Connected Calls" value={connected} icon={CheckCircle} grad={PALETTE[2].grad} accent={PALETTE[2].accent} />
            <KpiCard label="Total Interactions" value={totalInts} icon={Phone} grad={PALETTE[3].grad} accent={PALETTE[3].accent} />
            <KpiCard label="Avg Talk Time" value={avgTalk} icon={Clock} sub="s" grad={PALETTE[4].grad} accent={PALETTE[4].accent} />

          </div>

          {/* Top row: 3 tables */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16, marginBottom: 16 }}>
            <ActiveCampaignsReport isMini onExpand={() => setActiveTab('active-campaigns')} pal={PALETTE[0]} />
            <StaffedAgentsReport isMini onExpand={() => setActiveTab('staffed-agents')} pal={PALETTE[1]} />
            <DispositionReport isMini onExpand={() => setActiveTab('disposition-report')} pal={PALETTE[2]}
              miniTitle={dispCampId ? `Disposition – ${campaigns.find((c: any) => c.id === dispCampId)?.name || 'Campaign'}` : 'Disposition Report'} />
          </div>

          {/* Bottom row: 2 tables */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 16 }}>
            <InteractionReport isMini onExpand={() => setActiveTab('interaction-report')} pal={PALETTE[3]} />
            <AgentLoginReport isMini onExpand={() => setActiveTab('agent-login-report')} pal={PALETTE[4]} />
          </div>
        </>
      )}

      {/* ── Individual tabs ─────────────────────────────────────────── */}
      {activeTab === 'active-campaigns' && <ActiveCampaignsReport />}
      {activeTab === 'staffed-agents' && <StaffedAgentsReport />}
      {activeTab === 'disposition-report' && <DispositionReport />}
      {activeTab === 'interaction-report' && <InteractionReport />}
      {activeTab === 'agent-login-report' && <AgentLoginReport />}
    </div>
  );
}