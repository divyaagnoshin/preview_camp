import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getOrganization,
  updateOrganization,
  listOrgUsers,
  createOrgUser,
  deleteOrgUser,
  Organization,
  OrgAdmin,
} from '../api/client';
import {
  Badge,
  Button,
  Card,
  CardHeader,
  Input,
  Modal,
  PageLoader,
  Select,
  Textarea,
} from '../components/ui';
import {
  ArrowLeft,
  Building2,
  Users,
  ShieldCheck,
  UserPlus,
  Pencil,
  CalendarDays,
  Headphones,
  Trash2,
  UserCog,
} from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

// ---------- stat card ----------
function StatCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: typeof Users;
  label: string;
  value: number | string;
  color: string;
}) {
  return (
    <div className='bg-white border border-gray-200 rounded-xl p-5 flex items-center gap-4'>
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
        <Icon className='w-5 h-5' />
      </div>
      <div>
        <div className='text-2xl font-bold text-gray-900'>{value}</div>
        <div className='text-xs text-gray-500 mt-0.5'>{label}</div>
      </div>
    </div>
  );
}

// ---------- main page ----------
export default function OrganizationDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { setOrgContext } = useAuth();

  const [editOpen, setEditOpen] = useState(false);
  const [addUserOpen, setAddUserOpen] = useState(false);
  const [deleteUser, setDeleteUser] = useState<OrgAdmin | null>(null);

  const { data: orgData, isLoading } = useQuery({
    queryKey: ['organization', id],
    queryFn: () => getOrganization(id!),
    enabled: !!id,
  });

  const { data: usersData } = useQuery({
    queryKey: ['org-users', id],
    queryFn: () => listOrgUsers(id!),
    enabled: !!id,
  });

  const org: Organization | undefined = orgData;
  const users: OrgAdmin[] = usersData?.data || [];
  // Fall back to client-side counting if the backend hasn't enriched the
  // payload yet (older /organizations/:id responses only carried admin_count).
  const adminCount =
    (org as any)?.admin_count ?? users.filter((u) => u.role === 'admin').length;
  const supervisorCount =
    (org as any)?.supervisor_count ??
    users.filter((u) => u.role === 'supervisor').length;
  const agentCount =
    (org as any)?.agent_count ?? users.filter((u) => u.role === 'agent').length;
  const totalUsers = org?.user_count ?? users.length;

  if (isLoading) return <PageLoader />;
  if (!org) return (
    <div className='p-6 text-sm text-gray-500'>Organization not found.</div>
  );

  return (
    <div className='p-6 space-y-6 max-w-4xl'>
      {/* Header */}
      <div className='flex items-start justify-between'>
        <div className='flex items-center gap-3'>
          <button
            onClick={() => navigate('/organizations')}
            className='p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition'
          >
            <ArrowLeft className='w-4 h-4' />
          </button>
          <div className='w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center'>
            <Building2 className='w-5 h-5 text-indigo-600' />
          </div>
          <div>
            <h1 className='text-xl font-bold text-gray-900'>{org.name}</h1>
            {org.description && (
              <p className='text-sm text-gray-400 mt-0.5'>{org.description}</p>
            )}
          </div>
        </div>
        <div className='flex items-center gap-2'>
          <Button
            size='sm'
            variant='secondary'
            icon={<Pencil className='w-3.5 h-3.5' />}
            onClick={() => setEditOpen(true)}
          >
            Edit
          </Button>
          <Button
            size='sm'
            icon={<ShieldCheck className='w-3.5 h-3.5' />}
            onClick={() => {
              setOrgContext({ id: org.id, name: org.name });
              navigate('/dashboard');
            }}
          >
            Act as this org
          </Button>
        </div>
      </div>

      {/* Stats grid */}
      <div className='grid grid-cols-2 md:grid-cols-5 gap-4'>
        <StatCard
          icon={ShieldCheck}
          label='Admins'
          value={adminCount}
          color='bg-indigo-50 text-indigo-600'
        />
        <StatCard
          icon={UserCog}
          label='Supervisors'
          value={supervisorCount}
          color='bg-purple-50 text-purple-600'
        />
        <StatCard
          icon={Headphones}
          label='Agents'
          value={agentCount}
          color='bg-emerald-50 text-emerald-600'
        />
        <StatCard
          icon={Users}
          label='Total users'
          value={totalUsers}
          color='bg-blue-50 text-blue-600'
        />
        <StatCard
          icon={CalendarDays}
          label='Created'
          value={new Date(org.created_at).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
          })}
          color='bg-gray-100 text-gray-500'
        />
      </div>

      {/* Users list — every role under this tenant */}
      <Card>
        <CardHeader
          title='Users'
          subtitle={`${users.length} member${users.length !== 1 ? 's' : ''}`}
          action={
            <Button
              size='sm'
              icon={<UserPlus className='w-3.5 h-3.5' />}
              onClick={() => setAddUserOpen(true)}
            >
              Add user
            </Button>
          }
        />
        {users.length === 0 ? (
          <div className='px-5 py-8 text-center text-sm text-gray-400'>
            No users yet. Add one to get started.
          </div>
        ) : (
          <div className='divide-y divide-gray-100'>
            {users.map((u) => (
              <div
                key={u.id}
                className='flex items-center justify-between px-5 py-3'
              >
                <div className='flex items-center gap-3'>
                  <div className='w-7 h-7 bg-indigo-100 rounded-full flex items-center justify-center text-xs font-bold text-indigo-700'>
                    {u.first_name?.[0]}
                    {u.last_name?.[0]}
                  </div>
                  <div>
                    <div className='text-sm font-medium text-gray-900'>
                      {u.first_name} {u.last_name}
                    </div>
                    <div className='text-xs text-gray-400'>{u.email}</div>
                  </div>
                </div>
                <div className='flex items-center gap-2'>
                  <Badge
                    label={u.role}
                    color={
                      u.role === 'admin'
                        ? 'indigo'
                        : u.role === 'supervisor'
                          ? 'purple'
                          : 'green'
                    }
                  />
                  {!u.is_active && <Badge label='disabled' color='red' />}
                  <Button
                    size='sm'
                    variant='ghost'
                    icon={<Trash2 className='w-3.5 h-3.5' />}
                    onClick={() => setDeleteUser(u)}
                    className='text-red-600 hover:bg-red-50'
                  >
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Edit modal */}
      {editOpen && (
        <EditOrgModal
          org={org}
          onClose={() => setEditOpen(false)}
          onSaved={() => {
            setEditOpen(false);
            qc.invalidateQueries({ queryKey: ['organization', id] });
            qc.invalidateQueries({ queryKey: ['organizations'] });
          }}
        />
      )}

      {/* Add user modal */}
      {addUserOpen && (
        <CreateUserModal
          org={org}
          onClose={() => setAddUserOpen(false)}
          onCreated={() => {
            setAddUserOpen(false);
            qc.invalidateQueries({ queryKey: ['org-users', id] });
            qc.invalidateQueries({ queryKey: ['organization', id] });
            qc.invalidateQueries({ queryKey: ['organizations'] });
          }}
        />
      )}

      {/* Delete user modal */}
      {deleteUser && (
        <DeleteUserModal
          orgId={org.id}
          user={deleteUser}
          onClose={() => setDeleteUser(null)}
          onDeleted={() => {
            setDeleteUser(null);
            qc.invalidateQueries({ queryKey: ['org-users', id] });
            qc.invalidateQueries({ queryKey: ['organization', id] });
            qc.invalidateQueries({ queryKey: ['organizations'] });
          }}
        />
      )}
    </div>
  );
}

// ---------- Edit modal ----------
function EditOrgModal({
  org,
  onClose,
  onSaved,
}: {
  org: Organization;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState(org.name);
  const [description, setDescription] = useState(org.description || '');
  const [error, setError] = useState('');

  const m = useMutation({
    mutationFn: (body: { name: string; description: string | null }) =>
      updateOrganization(org.id, body),
    onSuccess: () => onSaved(),
    onError: (e: any) =>
      setError(e?.response?.data?.error || 'Failed to update organization'),
  });

  return (
    <Modal title={`Edit ${org.name}`} open={true} onClose={onClose}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          m.mutate({ name, description: description || null });
        }}
        className='space-y-4'
      >
        <Input
          label='Name'
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          autoFocus
        />
        <Textarea
          label='Description'
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
        />
        {error && <p className='text-xs text-red-500'>{error}</p>}
        <div className='flex justify-end gap-2 pt-2'>
          <Button type='button' variant='secondary' onClick={onClose}>
            Cancel
          </Button>
          <Button type='submit' loading={m.isPending}>
            Save
          </Button>
        </div>
      </form>
    </Modal>
  );
}

// ---------- Create user modal ----------
// Lets the superadmin provision any role (admin/supervisor/agent) directly
// inside the target organization. Mirrors the admin's `New user` modal so the
// experience is consistent across both entry points.
function CreateUserModal({
  org,
  onClose,
  onCreated,
}: {
  org: Organization;
  onClose: () => void;
  onCreated: () => void;
}) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'admin' | 'supervisor' | 'agent'>('admin');
  const [error, setError] = useState('');

  const m = useMutation({
    mutationFn: (body: {
      email: string;
      password: string;
      first_name: string;
      last_name: string;
      role: 'admin' | 'supervisor' | 'agent';
    }) => createOrgUser(org.id, body),
    onSuccess: () => onCreated(),
    onError: (e: any) =>
      setError(e?.response?.data?.error || 'Failed to create user'),
  });

  return (
    <Modal title={`Add user — ${org.name}`} open={true} onClose={onClose}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          m.mutate({
            email: email.trim(),
            password,
            first_name: firstName.trim(),
            last_name: lastName.trim(),
            role,
          });
        }}
        className='space-y-3'
      >
        <div className='grid grid-cols-2 gap-3'>
          <Input
            label='First name'
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            required
            autoFocus
          />
          <Input
            label='Last name'
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            required
          />
        </div>
        <Input
          label='Email'
          type='email'
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <Input
          label='Password (min 8 chars)'
          type='password'
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          minLength={8}
        />
        <Select
          label='Role'
          value={role}
          onChange={(e) =>
            setRole(e.target.value as 'admin' | 'supervisor' | 'agent')
          }
          options={[
            { value: 'admin', label: 'Admin' },
            { value: 'supervisor', label: 'Supervisor' },
            { value: 'agent', label: 'Agent' },
          ]}
        />
        {error && <p className='text-xs text-red-500'>{error}</p>}
        <div className='flex justify-end gap-2 pt-2'>
          <Button type='button' variant='secondary' onClick={onClose}>
            Cancel
          </Button>
          <Button type='submit' loading={m.isPending}>
            Create user
          </Button>
        </div>
      </form>
    </Modal>
  );
}

// ---------- Delete user modal ----------
function DeleteUserModal({
  orgId,
  user,
  onClose,
  onDeleted,
}: {
  orgId: string;
  user: OrgAdmin;
  onClose: () => void;
  onDeleted: () => void;
}) {
  const [error, setError] = useState('');
  const m = useMutation({
    mutationFn: () => deleteOrgUser(orgId, user.id),
    onSuccess: () => onDeleted(),
    onError: (e: any) =>
      setError(e?.response?.data?.error || 'Failed to delete user'),
  });

  return (
    <Modal
      title={`Delete ${user.first_name} ${user.last_name}?`}
      open={true}
      onClose={onClose}
    >
      <div className='space-y-4'>
        <p className='text-sm text-gray-600'>
          This removes <strong>{user.email}</strong> from the organization.
          If the user has historical activity, the account is deactivated
          instead of hard-deleted so audit history is preserved.
        </p>
        {error && <p className='text-xs text-red-500'>{error}</p>}
        <div className='flex justify-end gap-2'>
          <Button variant='secondary' onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant='danger'
            loading={m.isPending}
            onClick={() => m.mutate()}
          >
            Delete
          </Button>
        </div>
      </div>
    </Modal>
  );
}