import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  listOrganizations,
  createOrganization,
  updateOrganization,
  deleteOrganization,
  Organization,
} from '../api/client';
import {
  Button,
  Card,
  CardHeader,
  EmptyState,
  Input,
  Modal,
  PageLoader,
  Table,
  Textarea,
} from '../components/ui';
import { Building2, LogIn, Pencil, Plus, Trash2 } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

export default function OrganizationsPage() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { setOrgContext, orgContext, clearOrgContext } = useAuth();

  // Landing on the Organizations page resets any tenant context the
  // superadmin had previously activated, so the sidebar collapses back to
  // just "Organizations" until they click "Act as" on a specific row.
  useEffect(() => {
    if (orgContext) clearOrgContext();
    // Run only on mount; subsequent setOrgContext calls happen via the
    // "Act as" buttons and we don't want this effect to fight them.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [createOrgOpen, setCreateOrgOpen] = useState(false);
  const [editOrg, setEditOrg] = useState<Organization | null>(null);
  const [deleteOrg, setDeleteOrg] = useState<Organization | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['organizations'],
    queryFn: listOrganizations,
  });

  const orgs = data?.data || [];

  return (
    <div className='p-6 space-y-6'>
      <div className='flex items-center justify-between'>
        <div>
          <h1 className='text-xl font-bold text-gray-900'>Organizations</h1>
          <p className='text-sm text-gray-400 mt-0.5'>
            Manage tenant organizations and their administrators
          </p>
        </div>
        <Button
          icon={<Plus className='w-3.5 h-3.5' />}
          onClick={() => setCreateOrgOpen(true)}
        >
          New organization
        </Button>
      </div>

      <Card>
        <CardHeader title='All organizations' subtitle={`${orgs.length} total`} />
        {isLoading ? (
          <PageLoader />
        ) : orgs.length === 0 ? (
          <EmptyState
            title='No organizations yet'
            description='Create the first tenant organization to get started.'
            action={
              <Button
                icon={<Plus className='w-3.5 h-3.5' />}
                onClick={() => setCreateOrgOpen(true)}
              >
                New organization
              </Button>
            }
          />
        ) : (
          <Table
            cols={[
              {
                header: 'Name',
                render: (r: Organization) => (
                  <button
                    type='button'
                    onClick={() => navigate(`/organizations/${r.id}`)}
                    className='flex items-center gap-2 text-left hover:text-indigo-700'
                  >
                    <Building2 className='w-4 h-4 text-gray-400' />
                    <span className='font-medium text-gray-900 hover:text-indigo-700'>
                      {r.name}
                    </span>
                  </button>
                ),
              },
              {
                header: 'Description',
                render: (r: Organization) =>
                  r.description || <span className='text-gray-400'>—</span>,
              },
              {
                header: 'Admins',
                render: (r: Organization) => r.admin_count ?? 0,
                width: '80px',
              },
              {
                header: 'Users',
                render: (r: Organization) => r.user_count ?? 0,
                width: '80px',
              },
              {
                header: 'Created',
                render: (r: Organization) =>
                  new Date(r.created_at).toLocaleDateString(),
                width: '110px',
              },
              {
                header: 'Actions',
                render: (r: Organization) => (
                  <div className='flex items-center gap-1.5'>
                    {/* Act as — highlighted when this org is active */}
                    {/* <Button
                      size='sm'
                      variant={orgContext?.id === r.id ? 'primary' : 'secondary'}
                      icon={<LogIn className='w-3.5 h-3.5' />}
                      onClick={() => {
                        setOrgContext({ id: r.id, name: r.name });
                        navigate('/dashboard');
                      }}
                      title='Switch into this organization'
                    >
                      {orgContext?.id === r.id ? 'Active' : 'Act as'}
                    </Button> */}
                    <Button
                      size='sm'
                      variant='ghost'
                      icon={<Pencil className='w-3.5 h-3.5' />}
                      onClick={() => setEditOrg(r)}
                      title='Edit'
                    >
                      Edit
                    </Button>
                    <Button
                      size='sm'
                      variant='ghost'
                      icon={<Trash2 className='w-3.5 h-3.5' />}
                      onClick={() => setDeleteOrg(r)}
                      title='Delete'
                      className='text-red-600 hover:bg-red-50'
                    >
                      Delete
                    </Button>
                  </div>
                ),
                width: '260px',
              },
            ]}
            rows={orgs}
            keyFn={(r: Organization) => r.id}
            emptyMessage='No organizations'
          />
        )}
      </Card>

      <CreateOrgModal
        open={createOrgOpen}
        onClose={() => setCreateOrgOpen(false)}
        onCreated={() => {
          setCreateOrgOpen(false);
          qc.invalidateQueries({ queryKey: ['organizations'] });
        }}
      />

      {editOrg && (
        <EditOrgModal
          org={editOrg}
          onClose={() => setEditOrg(null)}
          onSaved={() => {
            setEditOrg(null);
            qc.invalidateQueries({ queryKey: ['organizations'] });
          }}
        />
      )}

      {deleteOrg && (
        <DeleteOrgModal
          org={deleteOrg}
          onClose={() => setDeleteOrg(null)}
          onDeleted={() => {
            setDeleteOrg(null);
            qc.invalidateQueries({ queryKey: ['organizations'] });
          }}
        />
      )}
    </div>
  );
}

function EditOrgModal({
  org,
  onClose,
  onSaved,
}: {
  org: Organization;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState(org.name);
  const [description, setDescription] = useState(org.description || '');
  const [error, setError] = useState('');

  const m = useMutation({
    mutationFn: (body: { name: string; description: string | null }) =>
      updateOrganization(org.id, body),
    onSuccess: () => onSaved(),
    onError: (e: any) =>
      setError(e?.response?.data?.error || 'Failed to update organization'),
  });

  return (
    <Modal title={`Edit ${org.name}`} open={true} onClose={onClose}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          m.mutate({ name, description: description || null });
        }}
        className='space-y-4'
      >
        <Input
          label='Name'
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          autoFocus
        />
        <Textarea
          label='Description'
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
        />
        {error && <p className='text-xs text-red-500'>{error}</p>}
        <div className='flex justify-end gap-2 pt-2'>
          <Button type='button' variant='secondary' onClick={onClose}>
            Cancel
          </Button>
          <Button type='submit' loading={m.isPending}>
            Save
          </Button>
        </div>
      </form>
    </Modal>
  );
}

function DeleteOrgModal({
  org,
  onClose,
  onDeleted,
}: {
  org: Organization;
  onClose: () => void;
  onDeleted: () => void;
}) {
  const [error, setError] = useState('');
  const m = useMutation({
    mutationFn: () => deleteOrganization(org.id),
    onSuccess: () => onDeleted(),
    onError: (e: any) =>
      setError(e?.response?.data?.error || 'Failed to delete organization'),
  });

  return (
    <Modal title={`Delete ${org.name}?`} open={true} onClose={onClose}>
      <div className='space-y-4'>
        <p className='text-sm text-gray-600'>
          This permanently removes the organization. The action will fail if
          the organization still has users, campaigns, or other related
          records — you must clear those out first.
        </p>
        {error && <p className='text-xs text-red-500'>{error}</p>}
        <div className='flex justify-end gap-2'>
          <Button variant='secondary' onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant='danger'
            loading={m.isPending}
            onClick={() => m.mutate()}
          >
            Delete
          </Button>
        </div>
      </div>
    </Modal>
  );
}

function CreateOrgModal({
  open,
  onClose,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  onCreated: () => void;
}) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');

  const m = useMutation({
    mutationFn: createOrganization,
    onSuccess: () => {
      setName('');
      setDescription('');
      setError('');
      onCreated();
    },
    onError: (e: any) =>
      setError(e?.response?.data?.error || 'Failed to create organization'),
  });

  return (
    <Modal title='New organization' open={open} onClose={onClose}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          m.mutate({ name, description: description || undefined });
        }}
        className='space-y-4'
      >
        <Input
          label='Name'
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          autoFocus
        />
        <Textarea
          label='Description (optional)'
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
        />
        {error && <p className='text-xs text-red-500'>{error}</p>}
        <div className='flex justify-end gap-2 pt-2'>
          <Button type='button' variant='secondary' onClick={onClose}>
            Cancel
          </Button>
          <Button type='submit' loading={m.isPending}>
            Create
          </Button>
        </div>
      </form>
    </Modal>
  );
}