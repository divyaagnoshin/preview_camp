/**
 * supervisorTeamsAndCampaigns.ts  —  Supervisor Teams + Campaign Mapping Routes
 *
 * Mount in index.ts:
 *   import supervisorTeamsRouter from './routes/supervisorTeamsAndCampaigns';
 *   app.use('/v1/supervisor-teams', supervisorTeamsRouter);
 *
 * This file provides:
 *   1. Supervisor Teams — which supervisors exist, which agents are under them
 *   2. Campaign–User Mapping — assign agents / supervisors to a campaign
 *
 * Role guards:
 *   admin      → full read + write
 *   supervisor → read only (their own team view)
 */

import { Router, Request, Response, NextFunction } from 'express';
import agnoPool, { withAgnoTransaction  } from '../db/agnoPool';
import { authenticate, requireRole } from '../middleware/auth';
import { AppError } from '../middleware/errorHandler';

const router = Router();
router.use(authenticate);

// ═══════════════════════════════════════════════════════════════
//  SECTION 1 — SUPERVISOR TEAMS
//  A "team" is implicitly defined by the users who have
//  role = 'supervisor' in the org.  Agents can be assigned to a
//  supervisor via the campaign_agent_assignments table or a
//  lightweight supervisor_agent_map table created below.
//
//  NOTE: This service assumes the following optional table exists
//  (run the migration snippet at the bottom of this file if it
//  does not yet exist in your database).
// ═══════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────
// GET /v1/supervisor-teams
// Return all supervisors with their assigned agents.
// ─────────────────────────────────────────────────────────────
router.get(
  '/',
  requireRole('admin', 'supervisor'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId, role, userId } = req.user!;

      // Supervisors see only their own team
      const supervisorFilter =
        role === 'supervisor' ? `AND s.id = '${userId}'` : '';

      // Fetch all supervisors with their agent list (left join so supervisors
      // with no agents still appear)
      const { rows } = await agnoPool.query(
  `SELECT
      s.userid AS supervisor_id,
      s.first_name AS supervisor_first_name,
      s.last_name AS supervisor_last_name,
      s.email_id AS supervisor_email,

      CASE
        WHEN LOWER(s.status) = 'active' THEN true
        ELSE false
      END AS supervisor_is_active

   FROM user_details s
   WHERE s.role_id = 2
   ORDER BY s.first_name`
);
      // Group flat rows into supervisor → agents structure
      const supervisorMap = new Map<
        string,
        {
          supervisor_id: string;
          supervisor_first_name: string;
          supervisor_last_name: string;
          supervisor_email: string;
          supervisor_is_active: boolean;
          agents: {
            id: string;
            first_name: string;
            last_name: string;
            email: string;
            is_active: boolean;
            assigned_at: string | null;
          }[];
        }
      >();

      for (const row of rows) {
        if (!supervisorMap.has(row.supervisor_id)) {
          supervisorMap.set(row.supervisor_id, {
            supervisor_id: row.supervisor_id,
            supervisor_first_name: row.supervisor_first_name,
            supervisor_last_name: row.supervisor_last_name,
            supervisor_email: row.supervisor_email,
            supervisor_is_active: row.supervisor_is_active,
            agents: [],
          });
        }
        if (row.agent_id) {
          supervisorMap.get(row.supervisor_id)!.agents.push({
            id: row.agent_id,
            first_name: row.agent_first_name,
            last_name: row.agent_last_name,
            email: row.agent_email,
            is_active: row.agent_is_active,
            assigned_at: row.assigned_at,
          });
        }
      }

      res.json({ data: [...supervisorMap.values()] });
    } catch (err) {
      next(err);
    }
  },
);

// ─────────────────────────────────────────────────────────────
// GET /v1/supervisor-teams/:supervisorId/agents
// List agents assigned to a specific supervisor.
// ─────────────────────────────────────────────────────────────
router.get(
  '/:supervisorId/agents',
  requireRole('admin', 'supervisor'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId, role, userId } = req.user!;

      // Supervisors can only see their own team
      if (role === 'supervisor' && req.params.supervisorId !== userId) {
        throw new AppError(403, 'You can only view your own team');
      }

      // Verify supervisor belongs to this org
      const { rows: sup } = await agnoPool.query(
        `SELECT id FROM users WHERE id = $1 AND org_id = $2 AND role = 'supervisor'`,
        [req.params.supervisorId, orgId],
      );
      if (!sup[0]) throw new AppError(404, 'Supervisor not found');

      const { rows } = await agnoPool.query(
        `SELECT
           a.id,
           a.first_name,
           a.last_name,
           a.email,
           a.is_active,
           sam.assigned_at
         FROM supervisor_agent_map sam
         JOIN users a ON a.id = sam.agent_id
         WHERE sam.supervisor_id = $1
           AND a.org_id = $2
         ORDER BY a.first_name, a.last_name`,
        [req.params.supervisorId, orgId],
      );

      res.json({ data: rows });
    } catch (err) {
      next(err);
    }
  },
);

// ─────────────────────────────────────────────────────────────
// POST /v1/supervisor-teams/:supervisorId/agents
// Assign one or more agents to a supervisor.
// Admin only.
//
// Body: { "agent_ids": ["uuid1", "uuid2"] }
// ─────────────────────────────────────────────────────────────
router.post(
  '/:supervisorId/agents',
  requireRole('admin'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId } = req.user!;
      const { agent_ids } = req.body || {};

      if (!Array.isArray(agent_ids) || agent_ids.length === 0)
        throw new AppError(400, 'agent_ids must be a non-empty array');

      // Verify supervisor
      const { rows: sup } = await agnoPool.query(
        `SELECT id FROM users WHERE id = $1 AND org_id = $2 AND role = 'supervisor'`,
        [req.params.supervisorId, orgId],
      );
      if (!sup[0]) throw new AppError(404, 'Supervisor not found');

      // Verify all agents belong to this org
      const { rows: validAgents } = await agnoPool.query(
        `SELECT id FROM users WHERE id = ANY($1::uuid[]) AND org_id = $2 AND role = 'agent'`,
        [agent_ids, orgId],
      );
      if (validAgents.length !== agent_ids.length)
        throw new AppError(400, 'One or more agent_ids are invalid or do not belong to this organisation');

      // Upsert — ignore if already assigned
      await withAgnoTransaction(async (client) => {
        for (const agentId of agent_ids) {
          await client.query(
            `INSERT INTO supervisor_agent_map (supervisor_id, agent_id)
             VALUES ($1, $2)
             ON CONFLICT (supervisor_id, agent_id) DO NOTHING`,
            [req.params.supervisorId, agentId],
          );
        }
      });

      res.status(201).json({ message: 'Agents assigned to supervisor successfully' });
    } catch (err) {
      next(err);
    }
  },
);

// ─────────────────────────────────────────────────────────────
// DELETE /v1/supervisor-teams/:supervisorId/agents/:agentId
// Remove an agent from a supervisor's team.
// Admin only.
// ─────────────────────────────────────────────────────────────
router.delete(
  '/:supervisorId/agents/:agentId',
  requireRole('admin'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId } = req.user!;

      // Verify both belong to org
      const { rows } = await agnoPool.query(
        `SELECT id FROM users WHERE id IN ($1, $2) AND org_id = $3`,
        [req.params.supervisorId, req.params.agentId, orgId],
      );
      if (rows.length < 2)
        throw new AppError(404, 'Supervisor or agent not found in this organisation');

      const { rowCount } = await agnoPool.query(
        `DELETE FROM supervisor_agent_map WHERE supervisor_id = $1 AND agent_id = $2`,
        [req.params.supervisorId, req.params.agentId],
      );

      if (!rowCount || rowCount === 0)
        throw new AppError(404, 'Assignment not found');

      res.json({ message: 'Agent removed from supervisor team' });
    } catch (err) {
      next(err);
    }
  },
);

// ═══════════════════════════════════════════════════════════════
//  SECTION 2 — CAMPAIGN–USER MAPPING
//  Assign agents and/or supervisors to a campaign so they can
//  work on it.  Stored in campaign_user_assignments table.
//
//  NOTE: Run the migration snippet at the bottom of this file
//  if the table does not yet exist.
// ═══════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────
// GET /v1/supervisor-teams/campaign-assignments/:campaignId
// Get all users (agents + supervisors) assigned to a campaign.
// ─────────────────────────────────────────────────────────────
router.get(
  '/campaign-assignments/:campaignId',
  requireRole('admin', 'supervisor'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId } = req.user!;

      // Verify campaign belongs to this org
      const { rows: campaign } = await agnoPool.query(
        `SELECT id, name FROM campaigns WHERE id = $1 AND org_id = $2`,
        [req.params.campaignId, orgId],
      );
      if (!campaign[0]) throw new AppError(404, 'Campaign not found');

      const { rows } = await agnoPool.query(
        `SELECT
           cua.id            AS assignment_id,
           cua.campaign_id,
           u.id              AS user_id,
           u.first_name,
           u.last_name,
           u.email,
           u.role,
           u.is_active,
           cua.assigned_at,
           cua.assigned_by
         FROM campaign_user_assignments cua
         JOIN users u ON u.id = cua.user_id
         WHERE cua.campaign_id = $1
           AND u.org_id = $2
         ORDER BY u.role DESC, u.first_name`,
        [req.params.campaignId, orgId],
      );

      res.json({
        campaign: campaign[0],
        data: rows,
      });
    } catch (err) {
      next(err);
    }
  },
);

// ─────────────────────────────────────────────────────────────
// POST /v1/supervisor-teams/campaign-assignments/:campaignId
// Assign agents / supervisors to a campaign.
// Admin only.
//
// Body: { "user_ids": ["uuid1", "uuid2"] }
// ─────────────────────────────────────────────────────────────
router.post(
  '/campaign-assignments/:campaignId',
  requireRole('admin'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId, userId: assignedBy } = req.user!;
      const { user_ids } = req.body || {};

      if (!Array.isArray(user_ids) || user_ids.length === 0)
        throw new AppError(400, 'user_ids must be a non-empty array');

      // Verify campaign belongs to this org
      const { rows: campaign } = await agnoPool.query(
        `SELECT id FROM campaigns WHERE id = $1 AND org_id = $2`,
        [req.params.campaignId, orgId],
      );
      if (!campaign[0]) throw new AppError(404, 'Campaign not found');

      // Verify all users are agents or supervisors in this org
      const { rows: validUsers } = await agnoPool.query(
        `SELECT id FROM users
         WHERE id = ANY($1::uuid[])
           AND org_id = $2
           AND role IN ('agent', 'supervisor')
           AND is_active = true`,
        [user_ids, orgId],
      );
      if (validUsers.length !== user_ids.length)
        throw new AppError(
          400,
          'One or more user_ids are invalid, inactive, or do not belong to this organisation',
        );

      // Upsert assignments
      await withAgnoTransaction(async (client) => {
        for (const userId of user_ids) {
          await client.query(
            `INSERT INTO campaign_user_assignments (campaign_id, user_id, assigned_by)
             VALUES ($1, $2, $3)
             ON CONFLICT (campaign_id, user_id) DO NOTHING`,
            [req.params.campaignId, userId, assignedBy],
          );
        }
      });

      res.status(201).json({ message: 'Users assigned to campaign successfully' });
    } catch (err) {
      next(err);
    }
  },
);

// ─────────────────────────────────────────────────────────────
// PUT /v1/supervisor-teams/campaign-assignments/:campaignId
// Replace all assignments for a campaign (full sync).
// Admin only.
//
// Body: { "user_ids": ["uuid1", "uuid2"] }
//   Pass an empty array to remove all assignments.
// ─────────────────────────────────────────────────────────────
router.put(
  '/campaign-assignments/:campaignId',
  requireRole('admin'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId, userId: assignedBy } = req.user!;
      const { user_ids } = req.body || {};

      if (!Array.isArray(user_ids))
        throw new AppError(400, 'user_ids must be an array');

      // Verify campaign
      const { rows: campaign } = await agnoPool.query(
        `SELECT id FROM campaigns WHERE id = $1 AND org_id = $2`,
        [req.params.campaignId, orgId],
      );
      if (!campaign[0]) throw new AppError(404, 'Campaign not found');

      // Verify users if any provided
      if (user_ids.length > 0) {
        const { rows: validUsers } = await agnoPool.query(
          `SELECT id FROM users
           WHERE id = ANY($1::uuid[])
             AND org_id = $2
             AND role IN ('agent', 'supervisor')
             AND is_active = true`,
          [user_ids, orgId],
        );
        if (validUsers.length !== user_ids.length)
          throw new AppError(400, 'One or more user_ids are invalid or inactive');
      }

      await withAgnoTransaction(async (client) => {
        // Remove all current assignments for this campaign
        await client.query(
          `DELETE FROM campaign_user_assignments WHERE campaign_id = $1`,
          [req.params.campaignId],
        );

        // Re-insert the new set
        for (const userId of user_ids) {
          await client.query(
            `INSERT INTO campaign_user_assignments (campaign_id, user_id, assigned_by)
             VALUES ($1, $2, $3)`,
            [req.params.campaignId, userId, assignedBy],
          );
        }
      });

      res.json({ message: 'Campaign assignments updated successfully' });
    } catch (err) {
      next(err);
    }
  },
);

// ─────────────────────────────────────────────────────────────
// DELETE /v1/supervisor-teams/campaign-assignments/:campaignId/:userId
// Remove a single user from a campaign.
// Admin only.
// ─────────────────────────────────────────────────────────────
router.delete(
  '/campaign-assignments/:campaignId/:userId',
  requireRole('admin'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId } = req.user!;

      // Verify campaign
      const { rows: campaign } = await agnoPool.query(
        `SELECT id FROM campaigns WHERE id = $1 AND org_id = $2`,
        [req.params.campaignId, orgId],
      );
      if (!campaign[0]) throw new AppError(404, 'Campaign not found');

      const { rowCount } = await agnoPool.query(
        `DELETE FROM campaign_user_assignments
         WHERE campaign_id = $1 AND user_id = $2`,
        [req.params.campaignId, req.params.userId],
      );

      if (!rowCount || rowCount === 0)
        throw new AppError(404, 'Assignment not found');

      res.json({ message: 'User removed from campaign' });
    } catch (err) {
      next(err);
    }
  },
);

export default router;

/*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  REQUIRED DB MIGRATIONS
  Add a new migration file (e.g. 028_supervisor_teams_and_campaign_users.sql)
  with the following SQL:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

-- Supervisor ↔ Agent mapping table
CREATE TABLE IF NOT EXISTS supervisor_agent_map (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  supervisor_id UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  agent_id      UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  assigned_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (supervisor_id, agent_id)
);

CREATE INDEX IF NOT EXISTS idx_sam_supervisor ON supervisor_agent_map(supervisor_id);
CREATE INDEX IF NOT EXISTS idx_sam_agent      ON supervisor_agent_map(agent_id);

-- Campaign ↔ User (agent/supervisor) assignment table
CREATE TABLE IF NOT EXISTS campaign_user_assignments (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID        NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  user_id     UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  assigned_by UUID        REFERENCES users(id),
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (campaign_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_cua_campaign ON campaign_user_assignments(campaign_id);
CREATE INDEX IF NOT EXISTS idx_cua_user     ON campaign_user_assignments(user_id);

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
*/