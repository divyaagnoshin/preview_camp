/**
 * user_details.ts  —  User Management Routes
 *
 * Mount in index.ts:
 *   import user_detailsRouter from './routes/user_details';
 *   app.use('/v1/user_details', user_detailsRouter);
 *
 * Allowed roles:
 *   • admin      – full CRUD on agents and supervisors within their org
 *   • supervisor – read-only (GET list / GET single)
 *
 * Role values stored in DB: 'agent' | 'supervisor'   (admin manages these two)
 * No "reporting_to" field — excluded by design.
 */

import { Router, Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import agnoPool from '../db/agnoPool';
import { authenticate, requireRole } from '../middleware/auth';
import { AppError } from '../middleware/errorHandler';

const router = Router();

// All routes require a valid JWT
router.use(authenticate);

// ─────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────

/** Roles that this endpoint is allowed to create / manage */
const ALLOWED_ROLES = ['agent', 'supervisor'] as const;
type AllowedRole = (typeof ALLOWED_ROLES)[number];

function assertAllowedRole(role: unknown): asserts role is AllowedRole {
  if (!ALLOWED_ROLES.includes(role as AllowedRole)) {
    throw new AppError(
      400,
      `role must be one of: ${ALLOWED_ROLES.join(', ')}`,
    );
  }
}

// ─────────────────────────────────────────────────────────────
// GET /v1/user_details
// List all agents and supervisors in the org.
// Admin sees everyone; supervisor sees only agents.
// ─────────────────────────────────────────────────────────────
router.get(
  '/',
  requireRole('admin', 'supervisor'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId, role } = req.user!;

      // Supervisors can only see agents in their org
      const roleFilter = role === 'supervisor' ? `AND u.role = 'agent'` : '';

      const { rows } = await agnoPool.query(
  `SELECT
      u.userid AS id,
      u.first_name,
      u.last_name,
      u.email_id AS email,

      CASE
        WHEN u.role_id = 2 THEN 'supervisor'
        ELSE 'agent'
      END AS role,

      CASE
        WHEN LOWER(u.status) = 'active' THEN true
        ELSE false
      END AS is_active,

      u.created_date AS created_at,
      u.updated_date AS updated_at

   FROM user_details u
  
   ORDER BY u.first_name, u.last_name`,
 
);

      res.json({ data: rows });
    } catch (err) {
      next(err);
    }
  },
);

// ─────────────────────────────────────────────────────────────
// GET /v1/user_details/:id
// Get a single user (agent or supervisor).
// ─────────────────────────────────────────────────────────────
router.get(
  '/:id',
  requireRole('admin', 'supervisor'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId } = req.user!;

      const { rows } = await agnoPool.query(
        `SELECT
           id,
           first_name,
           last_name,
           email,
           role,
           is_active,
           created_at,
           updated_at
         FROM user_details
         WHERE id = $1
           AND org_id = $2
           AND role IN ('agent', 'supervisor')`,
        [req.params.id, orgId],
      );

      if (!rows[0]) throw new AppError(404, 'User not found');
      res.json(rows[0]);
    } catch (err) {
      next(err);
    }
  },
);

// ─────────────────────────────────────────────────────────────
// POST /v1/user_details
// Create a new agent or supervisor.
// Admin only.
//
// Body:
// {
//   "first_name": "John",
//   "last_name":  "Doe",
//   "email":      "john@example.com",
//   "password":   "Str0ngPass!",
//   "role":       "agent"   // or "supervisor"
// }
// ─────────────────────────────────────────────────────────────
router.post(
  '/',
  requireRole('admin'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId, userId: createdBy } = req.user!;
      const { first_name, last_name, email, password, role } = req.body || {};

      // ── Validate required fields ──────────────────────────
      if (!first_name || typeof first_name !== 'string' || !first_name.trim())
        throw new AppError(400, 'first_name is required');
      if (!last_name || typeof last_name !== 'string' || !last_name.trim())
        throw new AppError(400, 'last_name is required');
      if (!email || typeof email !== 'string' || !email.trim())
        throw new AppError(400, 'email is required');
      if (!password || typeof password !== 'string' || password.length < 8)
        throw new AppError(400, 'password must be at least 8 characters');

      assertAllowedRole(role);

      const normalizedEmail = email.toLowerCase().trim();

      // ── Check for duplicate email within org ──────────────
      const { rows: existing } = await agnoPool.query(
        `SELECT id FROM user_details WHERE org_id = $1 AND email = $2`,
        [orgId, normalizedEmail],
      );
      if (existing.length > 0)
        throw new AppError(409, 'A user with this email already exists in the organisation');

      // ── Hash password ─────────────────────────────────────
      const password_hash = await bcrypt.hash(password, 12);

      // ── Insert user ───────────────────────────────────────
      const { rows } = await agnoPool.query(
        `INSERT INTO user_details (org_id, email, password_hash, first_name, last_name, role, is_active)
         VALUES ($1, $2, $3, $4, $5, $6, true)
         RETURNING id, first_name, last_name, email, role, is_active, created_at, updated_at`,
        [
          orgId,
          normalizedEmail,
          password_hash,
          first_name.trim(),
          last_name.trim(),
          role,
        ],
      );

      res.status(201).json(rows[0]);
    } catch (err) {
      next(err);
    }
  },
);

// ─────────────────────────────────────────────────────────────
// PATCH /v1/user_details/:id
// Update a user's profile or role.
// Admin only.
//
// Body (all fields optional):
// {
//   "first_name": "Jane",
//   "last_name":  "Smith",
//   "email":      "jane@example.com",
//   "role":       "supervisor",
//   "is_active":  false,
//   "password":   "NewPass123!"   // only include to change password
// }
// ─────────────────────────────────────────────────────────────
router.patch(
  '/:id',
  requireRole('admin'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId } = req.user!;
      const { first_name, last_name, email, role, is_active, password } =
        req.body || {};

      // ── Verify the target user exists and belongs to the org ──
      const { rows: existing } = await agnoPool.query(
        `SELECT id, role FROM user_details WHERE id = $1 AND org_id = $2 AND role IN ('agent', 'supervisor')`,
        [req.params.id, orgId],
      );
      if (!existing[0]) throw new AppError(404, 'User not found');

      // ── Validate optional fields ──────────────────────────
      if (role !== undefined) assertAllowedRole(role);

      if (
        email !== undefined &&
        (typeof email !== 'string' || !email.trim())
      ) {
        throw new AppError(400, 'email must be a non-empty string');
      }

      if (password !== undefined) {
        if (typeof password !== 'string' || password.length < 8)
          throw new AppError(400, 'password must be at least 8 characters');
      }

      // ── Build SET clause dynamically ──────────────────────
      const setClauses: string[] = ['updated_at = NOW()'];
      const params: unknown[] = [];
      let idx = 1;

      if (first_name !== undefined) {
        setClauses.push(`first_name = $${idx++}`);
        params.push(first_name.trim());
      }
      if (last_name !== undefined) {
        setClauses.push(`last_name = $${idx++}`);
        params.push(last_name.trim());
      }
      if (email !== undefined) {
        // Duplicate-email check (exclude self)
        const { rows: dup } = await agnoPool.query(
          `SELECT id FROM user_details WHERE org_id = $1 AND email = $2 AND id <> $3`,
          [orgId, email.toLowerCase().trim(), req.params.id],
        );
        if (dup.length > 0)
          throw new AppError(409, 'Another user with this email already exists');

        setClauses.push(`email = $${idx++}`);
        params.push(email.toLowerCase().trim());
      }
      if (role !== undefined) {
        setClauses.push(`role = $${idx++}`);
        params.push(role);
      }
      if (is_active !== undefined) {
        setClauses.push(`is_active = $${idx++}`);
        params.push(Boolean(is_active));
      }
      if (password !== undefined) {
        const hash = await bcrypt.hash(password, 12);
        setClauses.push(`password_hash = $${idx++}`);
        params.push(hash);
      }

      params.push(req.params.id, orgId);

      const { rows } = await agnoPool.query(
        `UPDATE user_details
         SET ${setClauses.join(', ')}
         WHERE id = $${idx++} AND org_id = $${idx}
         RETURNING id, first_name, last_name, email, role, is_active, created_at, updated_at`,
        params,
      );

      res.json(rows[0]);
    } catch (err) {
      next(err);
    }
  },
);

// ─────────────────────────────────────────────────────────────
// DELETE /v1/user_details/:id
// Soft-delete (deactivate) a user.
// Admin only.  Hard-delete is blocked if the user has interactions.
// ─────────────────────────────────────────────────────────────
router.delete(
  '/:id',
  requireRole('admin'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { orgId } = req.user!;

      const { rows: existing } = await agnoPool.query(
        `SELECT id FROM user_details WHERE id = $1 AND org_id = $2 AND role IN ('agent', 'supervisor')`,
        [req.params.id, orgId],
      );
      if (!existing[0]) throw new AppError(404, 'User not found');

      // Check for linked interactions — soft-delete instead of hard-delete
      const { rows: linked } = await agnoPool.query(
        `SELECT 1 FROM contact_interactions WHERE agent_id = $1 LIMIT 1`,
        [req.params.id],
      );

      if (linked.length > 0) {
        // Soft-delete: just deactivate
        await agnoPool.query(
          `UPDATE user_details SET is_active = false, updated_at = NOW() WHERE id = $1`,
          [req.params.id],
        );
        return res.json({
          message: 'User deactivated (has existing interactions, cannot be removed entirely)',
        });
      }

      // Hard-delete if no interactions exist
      await agnoPool.query(`DELETE FROM user_details WHERE id = $1`, [req.params.id]);
      res.json({ message: 'User deleted successfully' });
    } catch (err) {
      next(err);
    }
  },
);

// ─────────────────────────────────────────────────────────────
// GET /v1/user_details/roles/available
// Returns the list of roles the current user is allowed to assign.
// Agents see nothing; supervisors see only 'agent';
// admins see 'agent' and 'supervisor'.
// ─────────────────────────────────────────────────────────────
router.get(
  '/roles/available',
  requireRole('admin', 'supervisor'),
  (req: Request, res: Response) => {
    const { role } = req.user!;

    let roles: AllowedRole[] = [];
    if (role === 'admin') {
      roles = ['agent', 'supervisor'];
    } else if (role === 'supervisor') {
      roles = ['agent'];
    }

    res.json({ data: roles });
  },
);

export default router;